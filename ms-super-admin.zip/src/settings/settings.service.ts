import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";
import { Setting } from "src/schema/setting.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";


@Injectable()
export class SettingsService{
    constructor(@InjectModel(Setting.name) readonly SettingModel:Model<Setting>){}
    
    async payment_gateway(payload:any){
        try {
            const { payment_gateway, setting_id }=payload.body
            console.log(payload);
            if(!setting_id){
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `setting_id ${MessageConstant?.IS_REQUIRED}`,
                });
            }

            const create_setting=await this.SettingModel.findByIdAndUpdate({_id:setting_id},{$set:{payment_gateway}},{new:true})

            if (!create_setting){
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `Setting not found ${MessageConstant?.IS_REQUIRED}`,
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                message: `Setting ${MessageConstant?.UPDATED_SUCCESS}`,
            });

        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }
}
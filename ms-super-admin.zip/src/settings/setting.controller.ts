import { Body, Controller } from "@nestjs/common";
import { SettingsService } from "./settings.service";
import { MessagePattern } from "@nestjs/microservices";


@Controller()
export class SettingController{
    constructor(private readonly SettingService:SettingsService){}

    @MessagePattern({cmd:"payment_gateway"})
    async payment_gateway(@Body() body:any){
        return await this.SettingService.payment_gateway(body)
    }
}
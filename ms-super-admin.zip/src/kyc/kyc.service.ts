import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { Users } from "src/schema/User.schema";
import { Kyc } from "src/schema/kyc.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";


@Injectable()
export class KycService {
    constructor(@InjectModel(Users.name) readonly UsersModel: Model<Users>,
        @InjectModel(Kyc.name) readonly KycModel: Model<Kyc>
    ) { }


    async kyc_accpect(payload: any) {
        try {
            
            const { type, id,verified_reason } = payload.body
            console.log(payload.body)
            let verify: any
            if (type == "Pending") {
                verify = "Pending"
            }
            
            else if (type == "verified") {
                verify = "verified"
            }
            else {
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "invalid type"
                });
            }

            const find_user = await this.KycModel.findOne({ _id: id })

            if (find_user) {
                const update_kyc = await this.KycModel.findByIdAndUpdate({ _id: id }, { $set: { verified: verify, verified_reason: verified_reason, } })

                if (update_kyc) {

                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: verify = "Pending" ? "kyc Pending" : verify = "verified" ? "kyc verified" : "kyc Unverified"
                    });
                }
            }

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: [],
                message: "no user"
            });


        } catch (error) {
            await CatchErrorResponseHelper(error);
        }
    }
}
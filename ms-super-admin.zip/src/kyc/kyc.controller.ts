import { Body, Controller } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";

import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";
import { KycService } from "./kyc.service";
import { MessagePattern } from "@nestjs/microservices";

@Controller()
export class KycController {

    constructor(private readonly KycService: KycService) { }

    @MessagePattern({ cmd: 'kyc_update' })
    kyc_accpect(@Body() payload: any) {
        return this.KycService.kyc_accpect(payload)
    }


}
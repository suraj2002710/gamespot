import { Body, Controller } from "@nestjs/common";
import { Game_Category_Service } from "./game_category.service";
import { MessagePattern } from "@nestjs/microservices";



@Controller()
export class Game_CategoryController{
    constructor(private readonly Game_Category_Servie:Game_Category_Service){}

    @MessagePattern({ cmd:"create_category"})
    async create_category(@Body() body: any){
        return await this.Game_Category_Servie.create_Category(body)
    }
    @MessagePattern({ cmd:"update_Category"})
    async update_Category(@Body() body: any){
        return await this.Game_Category_Servie.update_Category(body)
    }
    @MessagePattern({ cmd:"delete_Category"})
    async delete_Category(@Body() body: any){
        return await this.Game_Category_Servie.delete_Category(body)
    }
    @MessagePattern({ cmd:"get_single_Category"})
    async get_single_Category(@Body() body: any){
        return await this.Game_Category_Servie.get_single_Category(body)
    }
    @MessagePattern({ cmd:"get_all_Category"})
    async get_all_Category(@Body() body: any){
        return await this.Game_Category_Servie.get_all_Category(body)
    }
}
import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { GamesCategory } from "src/schema/game_category.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";


@Injectable()
export class Game_Category_Service{
    constructor(@InjectModel(GamesCategory.name) readonly GamesCategoryModel:Model<GamesCategory>){}

    async create_Category(payload:any){
        try {
            const { name, details,active }=payload.body
            const find_category=await this.GamesCategoryModel.findOne({name})
            if(find_category){
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "This Category Already Exits."
                });
            }
            const create_category=await this.GamesCategoryModel.create({
                name, active, details
            })
            if(create_category){
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: "Category Create Successfully."
                });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async get_all_Category(payload:any){
        try {
            const {limit,page}=payload.body
            let skip=(page-1)*limit
            const find_category=await this.GamesCategoryModel.find().limit(limit).skip(skip)
            let count=await this.GamesCategoryModel.countDocuments()
            console.log(find_category);
            
            if(find_category.length){
                
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data:{row:find_category,count},
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: [],
                message: "No Category Found."
            });
            
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async get_single_Category(payload: any) {
        try {
            const { id } = payload.body
            
            const find_category = await this.GamesCategoryModel.findOne({_id:id})
            let count = await this.GamesCategoryModel.countDocuments()
            if (find_category) {

                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data:  find_category,
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: null,
                message: "No Category Found."
            });

        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async update_Category(payload: any) {
        try {
            const { name, details, active,id } = payload.body
            
            const find_category = await this.GamesCategoryModel.findOne({name:name,
                _id:{$ne:id}})

            if(find_category){
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                   message:"This Name of Category is Already Exits"
                });
            }

            const update_data = await this.GamesCategoryModel.findByIdAndUpdate({ _id: id }, { $set: { name, details, active }})


            if (update_data) {
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message:"Category Update Successfully"
                });
            }

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: null,
                message: "No Category Found."
            });

        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async delete_Category(payload: any) {
        try {
            const {id } = payload.body

            const find_category = await this.GamesCategoryModel.findOne({_id:id})
            if (find_category) {

                await this.GamesCategoryModel.deleteOne({_id:id})

                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: "Category Delete Successfully"
                });
         
            }         

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: null,
                message: "No Category Found."
            });

        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }
}
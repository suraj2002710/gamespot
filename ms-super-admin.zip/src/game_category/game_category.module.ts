import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { GamesCategory, GamesCategorySchema } from "src/schema/game_category.schema";
import { Game_CategoryController } from "./game_category.controller";
import { Game_Category_Service } from "./game_category.service";


@Module({
    imports:[
        MongooseModule.forFeature([
            {name:GamesCategory.name,schema:GamesCategorySchema}
        ])
    ],
    controllers:[Game_CategoryController],
    providers:[Game_Category_Service]
})
export class Game_CategoryModule{}
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { CommonConfig } from './config/CommanConfig';
import { Transport } from '@nestjs/microservices';

async function bootstrap() {
  const app = await NestFactory.createMicroservice(AppModule, {
    transport: Transport.TCP,
    options: {
      host: <any>CommonConfig?.HOST_MAIN_ADMIN,
      port: <any>CommonConfig?.PORT_MAIN_ADMIN,
    }
  });
  await app.listen();
}
bootstrap();

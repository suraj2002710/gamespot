import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';


export type Global_t_dataDocument = HydratedDocument<Global_t_data>;

@Schema({ timestamps: true })
export class Global_t_data {

    @Prop({ default: 0 })
    security_deposit: Number;

    @Prop({ default: 0 })
    threshold_deposit: Number;

    @Prop({ default: 0 })
    total_prepayment: Number;

    @Prop({ default: 0 })
    totaldeposit: Number;

    @Prop({ default: 0 })
    totaldepositamount: Number;

    @Prop({ default: 0 })
    totalwithdraw: Number;

    @Prop({ default: 0 })
    totalwithdrawamount: Number;

    @Prop({ default: 0 })
    totalbonus: Number;

    @Prop({ default: 0 })
    totalbonusAmount: Number;

    @Prop({ default: 0 })
    totalpenelty: Number;

    @Prop({ default: 0 })
    totalpeneltyAmount: Number;

    @Prop({ default: 0 })
    startAmount: Number;

    @Prop({ default: 0 })
    SettledAmount: Number;

    @Prop({ default: Date.now() })
    date: Date;

    @Prop({ default: 0 })
    u_bonus: Number;

    @Prop({ default: 0 })
    u_palenty: Number;

    @Prop({ default: 0 })
    u_totaldeposite: Number;

    @Prop({ default: 0 })
    u_deposite_amount: Number;

    @Prop({ default: 0 })
    u_totalwithdrawle: Number;

    @Prop({ default: 0 })
    u_withdrawle_amount: Number;


}

export const Global_t_dataSchema = SchemaFactory.createForClass(Global_t_data);
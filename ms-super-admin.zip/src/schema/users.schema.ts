import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

// import { Admin } from '../schemas/admins.schema';

export type UsersDocument = HydratedDocument<Users>;

@Schema({ timestamps: true })
export class Users {

    @Prop()
    name: string;

    @Prop({ default: '' })
    otp: string;

    @Prop()
    otp_expiry_time: Date;

    @Prop()
    email: string;

    @Prop({ default: null })
    Email_varified_at: Date;

    @Prop()
    phone_number: String;

    @Prop({ default: null })
    phone_varified_at: Date;

    @Prop({ required: true })
    password: string;

    @Prop({ default: "Self" })
    Register_by: string;

    @Prop({ default: 0 })
    Wallet_balance: Number;

    @Prop({ default: 0 })
    ref_Commision: Number;

    @Prop({ default: null })
    referral: string;

    @Prop({ required: true })
    referral_code: string;

    @Prop({ default: 0 })
    referral_earning: Number;

    @Prop({ default: 0 })
    wonAmount: Number;

    @Prop({ default: 0 })
    loseAmount: Number;

    @Prop({ default: 0 })
    totalDeposit: Number;

    @Prop({ default: 0 })
    withdrawAmount: Number;

    @Prop({ default: 0 })
    totalBonus: Number;

    @Prop({ default: 0 })
    totalPenalty: Number;

    @Prop({ default: 0, min: 0 })
    withdraw_holdbalance: Number;

    @Prop({ default: 0 })
    totalWithdrawl: Number;

    @Prop({ default: 'unverified', enum:['unverified', 'Pending' ,'verified']} )
    verified: String;

    @Prop()
    avatar: String;

    @Prop()
    tokens: String;

    @Prop({ default: '' })
    firebaseToken: String;

    @Prop({ default: null })
    lastWitdrawl: Number;

    @Prop({ default: null })
    holder_name: String;

    @Prop({ default: null })
    account_number: String;

    @Prop({ default: null })
    ifsc_code: String;

    @Prop()
    timestamps: true;

    @Prop()
    status: number;
    //aks
    @Prop()
    country: String;

    @Prop()
    country_code: String;

    @Prop()
    currency: String;

    @Prop()
    promo_code: String;

    @Prop({ required: true })
    username: String;

    @Prop({ required: true })
    profile_pic: String;

    @Prop()
    agency_id: String;

    @Prop()
    referal_wallet_amt: Number;

    @Prop({default:null})
    rzp_fund_acc: string;

    @Prop({default:null})
    rzp_contact: string;

    @Prop({ default: null })
    upi_id:string;

}


export const UsersSchema = SchemaFactory.createForClass(Users);
import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type SettingDocument = HydratedDocument<Setting>;

@Schema({ timestamps: true })
export class Setting {
   

    @Prop({
        type: Array,
    })
    payment_gateway: Array<{
        payment_app:String,
        Status:Boolean
    }>;

}

export const SettingSchema = SchemaFactory.createForClass(Setting);
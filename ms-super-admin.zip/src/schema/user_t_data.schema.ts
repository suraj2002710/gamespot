import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
import { Users } from './User.schema';
import { Global_t_data } from './global_t_data.schema';

export type User_t_dataDocument = HydratedDocument<User_t_data>;

@Schema({ timestamps: true })
export class User_t_data {

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Global_t_data' })
    global_t_data_id: Global_t_data;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Users' })
    user_id: Users;

    @Prop({ default: 0 })
    total_prepayment: Number;

    @Prop({ default: 0 })
    totaldeposit: Number;

    @Prop({ default: 0 })
    totaldepositamount: Number;

    @Prop({ default: 0 })
    totalwithdraw: Number;

    @Prop({ default: 0 })
    totalwithdrawamount: Number;

    @Prop({ default: 0 })
    totalbonus: Number;

    @Prop({ default: 0 })
    totalbonusAmount: Number;

    @Prop({ default: 0 })
    totalpenelty: Number;

    @Prop({ default: 0 })
    totalpeneltyAmount: Number;

    @Prop({ default: 0 })
    startAmount: Number;

    @Prop({ default: 0 })
    SettledAmount: Number;

    @Prop({ default: Date.now() })
    date: Date;

}

export const User_t_dataSchema = SchemaFactory.createForClass(User_t_data);
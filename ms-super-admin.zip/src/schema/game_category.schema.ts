import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
import { CommonConfig } from 'src/config/CommanConfig';



export type GamesDocument = HydratedDocument<GamesCategory>;

@Schema({ timestamps: true })
export class GamesCategory {
    @Prop()
    name: string;

    @Prop()
    slug: string;

    @Prop()
    active: Boolean;

    @Prop()
    details: mongoose.Schema.Types.Array

    @Prop()
    type: String




}

export const GamesCategorySchema = SchemaFactory.createForClass(GamesCategory);



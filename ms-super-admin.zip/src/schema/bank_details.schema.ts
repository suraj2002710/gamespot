import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";

import mongoose, { HydratedDocument } from "mongoose";
import { Users } from "./User.schema";

export type BanckDetailsDocument = HydratedDocument<BanckDetails>

@Schema()
export class BanckDetails {

    @Prop({ required: true })
    accountNumber: string;

    @Prop({ required: true, ref: "Users", type: mongoose.Schema.Types.ObjectId })
    User_Id: Users;

    @Prop({ required: true })
    bankName: string;

    @Prop({ required: true })
    ifsc_code: string;

    @Prop({ required: true })
    branch_name: string;

    @Prop({ default: 0, enum: [0, 1, 2] })  //0=pending,1=verified 2=rejected
    verified: Number;

    @Prop({ default: "" })  //0=pending,1=accpeted 2=rejected
    verified_reason: String;
}

export const BanckDetailsSchema = SchemaFactory.createForClass(BanckDetails)
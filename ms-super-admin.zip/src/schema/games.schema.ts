import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
import { CommonConfig } from 'src/config/CommanConfig';
import { GamesCategory } from './game_category.schema';



export type GamesDocument = HydratedDocument<Games>;

@Schema({ timestamps: true, toJSON: { virtuals: true } })
export class Games {
    @Prop()
    game_id: number;

    @Prop()
    name: string;

    @Prop()
    page_code: string;

    @Prop()
    system_id: number;  // merchant id

    @Prop()
    image_path: string;

    @Prop({ type:[{type: mongoose.Schema.Types.ObjectId, ref: "GamesCategory" }]})
    categories: Array<GamesCategory>;

    @Prop()
    sortpercategory: mongoose.Schema.Types.Array;

    @Prop()
    server_image: string;

    @Prop()
    countries: mongoose.Schema.Types.Array;

    @Prop()
    currency: mongoose.Schema.Types.Array;

    @Prop({ default: 0 })
    order_by: Number;
    @Prop()
    has_demo: number;

}

export const GamesSchema = SchemaFactory.createForClass(Games);

GamesSchema.virtual('full_image_path').get(function (this: GamesDocument) {
    if (this.server_image) {
        return CommonConfig?.GCP_BASE_PATH + this.server_image;
    } else {
        return CommonConfig?.GAME_IMAGE_DOMAIN + this.image_path;
    }
});

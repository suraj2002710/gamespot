import { Body, Controller } from "@nestjs/common";
import { GameService } from "./game.service";
import { MessagePattern } from "@nestjs/microservices";


@Controller()
export class GamesController{
    constructor(private readonly GameService:GameService){}

    @MessagePattern({ cmd:"game_create"})
    async game_create(@Body() body:any){
        return await this.GameService.createGame(body)
    }

    @MessagePattern({ cmd:"get_all_Game"})
    async get_all_game(@Body() body:any){
        return await this.GameService.get_all_Game(body)
    }

    @MessagePattern({ cmd:"get_single_Game"})
    async get_single_Game(@Body() body:any){
        return await this.GameService.get_single_Game(body)
    }

    @MessagePattern({ cmd:"delete_Game"})
    async delete_Game(@Body() body:any){
        return await this.GameService.delete_Game(body)
    }

    @MessagePattern({ cmd:"updateGame"})
    async updateGame(@Body() body:any){
        return await this.GameService.updateGame(body)
    }
}
import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import mongoose from "mongoose";
import { Games, GamesSchema } from "src/schema/games.schema";
import { GamesController } from "./gmae.controller";
import { GameService } from "./game.service";

@Module({
    imports:[MongooseModule.forFeature([
        {name:Games.name,schema:GamesSchema}
    ])],
    controllers:[GamesController],
    providers:[GameService]
})
export class GamesModule{}
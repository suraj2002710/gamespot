import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { Games } from "src/schema/games.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";


@Injectable()
export class GameService{
    constructor(@InjectModel(Games.name) readonly GameModel:Model<Games>){}

    async createGame(payload:any){
        try {
            const { name, categories, countries, currency, order_by }=payload.body
            console.log(payload.file,payload.body);

            // write code for image upload after bucket crediential

            let image_path=""
            
            const create_game=await this.GameModel.create({
                name, categories, countries, currency, order_by, image_path
            })
            if(create_game){
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: `Game Create Successfully`,
                    data: create_game
                });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async get_all_Game(payload: any) {
        try {
            const {page,limit } = payload.body
            let skip=(page-1)*limit
            const find_game = await this.GameModel.find().skip(skip).limit(limit)
            const count = await this.GameModel.countDocuments()
            if (find_game) {
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data: {row:find_game,count},
                });
            }

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                message: `Games Not Found`,
                data: { row: [], count },
            });
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async   get_single_Game(payload: any) {
        try {
            const { id } = payload.body
            const find_game = await this.GameModel.findOne({_id:id })
            if (find_game) {
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data: find_game,
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: [],
                message:"Game Not Found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async delete_Game(payload: any) {
        try {
            const { id } = payload.body
            const find_game = await this.GameModel.findOne({_id:id })
            if (find_game) {

                await this.GameModel.deleteOne({_id:id})
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message:"Game Delete Successfully"
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: [],
                message:"Game Not Found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async updateGame(payload: any) {
        try {
            const {game_id, name, categories, countries, currency, order_by } = payload.body
            console.log(payload.file, payload.body);

            const find_game = await this.GameModel.findOne({ _id: game_id })
            if (!find_game) {
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "Game Not Found"
                });
            }
            // write code for image upload after bucket crediential

            let image_path = ""

           
            const update_game = await this.GameModel.findByIdAndUpdate({ _id: game_id },{
                name, categories, countries, currency, order_by, image_path,
            })
            if (update_game) {
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: `Game Update Successfully`,
                });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

}
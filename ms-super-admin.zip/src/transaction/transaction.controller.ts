import { Body, Controller } from '@nestjs/common';

import { MessagePattern } from '@nestjs/microservices';
import { TransactionsService } from './transaction.service';

@Controller()
export class TransactionsController {
    constructor(private readonly transactionsService: TransactionsService) { }

    @MessagePattern({ cmd: 'withdrawleTransaction_action' })
    withdrawleTransaction_action(@Body() payload: any) {
        return this.transactionsService.withdrawleTransaction_action(payload)
    }
 

}

import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Transaction, TransactionSchema } from 'src/schema/transaction.schema';

import { MainAdmin, MainAdminSchema } from 'src/schema/main_admin.schema';
import { Users, UsersSchema } from 'src/schema/User.schema';
import { TransactionsController } from './transaction.controller';
import { TransactionsService } from './transaction.service';




@Module({
    imports: [MongooseModule.forFeature([
        { name: Users.name, schema: UsersSchema },
        { name: Transaction.name, schema: TransactionSchema },
        { name: MainAdmin.name, schema: MainAdminSchema },

    ])],
    controllers: [TransactionsController],
    providers: [TransactionsService]
})
export class TransactionsModule { }

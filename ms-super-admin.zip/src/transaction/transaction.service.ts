import { Injectable } from '@nestjs/common';
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import * as moment from 'moment';
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";

import { CatchErrorResponseHelper, QueryErrorResponseHelper, ResponseHelper } from "src/utils/Response";
import { Transaction } from 'src/schema/transaction.schema';
import { MainAdmin } from 'src/schema/main_admin.schema';
import { Users } from 'src/schema/User.schema';
import { Global_t_data } from 'src/schema/global_t_data.schema';
import { User_t_data } from 'src/schema/user_t_data.schema';

@Injectable()
export class TransactionsService {

    constructor(
        @InjectModel(Users.name) private readonly UsersSchema: Model<Users>,
        @InjectModel(Transaction.name) private readonly TransactionSchema: Model<Transaction>,
        @InjectModel(MainAdmin.name) private readonly Main_Admin_Service: Model<MainAdmin>,
        @InjectModel(MainAdmin.name) private readonly User_t_dataSchema: Model<User_t_data>,
        @InjectModel(MainAdmin.name) private readonly Global_t_dataSchema: Model<Global_t_data>,
    ) { }


    async withdrawleTransaction_action(payload: any) {
        try {

            console.log("wihdrawle");

            const { txn_mg, actiontype, transaction_id, status, order_token, agent_id } = payload.body

            const transection: any = await this.TransactionSchema.findOne({ _id: transaction_id })
                .populate('user_id', 'Wallet_balance totalWithdrawl totalDeposit')
                .populate('varified_by', 'prepayment totalwithdraw withdrwalCommision totalDeposit totalcommission_inhand');
            const agent: any = await this.Main_Admin_Service.findOne({ _id: agent_id });

            if (transection && agent) {
               
             

                if (transection.status != 1 && status == 1) {


                    const updatetransaction = await this.TransactionSchema.findByIdAndUpdate({ _id: transaction_id }, { $set: { status: 1, updatedAt: new Date(Date.now()) } })

                } else if (transection.status != 2 && status == 2) {
                    const updatetransaction = await this.TransactionSchema.findByIdAndUpdate({ _id: transaction_id }, { $set: { status: 2, updatedAt: new Date(Date.now()) } })
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `withdraw decline`,
                    });
                }
                else if (transection.status != 3 && status == 3) {
                    const updatetransaction = await this.TransactionSchema.findByIdAndUpdate({ _id: transaction_id }, { $set: { status: 3, updatedAt: new Date(Date.now()) } })
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `withdraw on hold`,
                    });
                } else {
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `invalid request or already proceed`,
                    });
                }


            } else {
                await QueryErrorResponseHelper({
                    code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `Agent ${MessageConstant?.IS_NOT_FOUND}`
                }, {
                    custom_code: StatusCode?.HTTP_BAD_REQUEST,
                    custom_message: `Agent ${MessageConstant?.IS_NOT_FOUND}`
                });
            }


        } catch (error) {
            console.log('error>>>', error)
            await CatchErrorResponseHelper(error);
        }
    }


}

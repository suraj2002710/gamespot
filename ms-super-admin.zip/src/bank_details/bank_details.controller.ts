import { Body, Controller } from "@nestjs/common";
import { Model } from "mongoose";
import { BanckDetailsServicse } from "./bank_details.service";
import { MessagePattern } from "@nestjs/microservices";


@Controller()
export class BanckDetailsController{
    constructor(private readonly BanckDetailsServicse:BanckDetailsServicse){}

    @MessagePattern({ cmd:"approve_bank_details"})
    async approve_bank_details(@Body() body:any){
        return await this.BanckDetailsServicse.approve_bank_details(body)
    }
}
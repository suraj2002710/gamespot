import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { BanckDetails } from "src/schema/bank_details.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";



@Injectable()
export class BanckDetailsServicse{
    constructor(@InjectModel(BanckDetails.name) readonly BanckDetailsSchema:Model<BanckDetails>) {}

    async approve_bank_details(payload: any) {
        try {
            const { id, verified, verified_reason } = payload.body
           
            
            const find_bank_detail=await this.BanckDetailsSchema.findById(id)

            if(find_bank_detail){
                const update_bank_details = await this.BanckDetailsSchema.findByIdAndUpdate({_id:id},{
                    verified,verified_reason
                })

                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: `Bank Detail ${verified==1?"Verified":"Rejected"}`
                });
            }

        

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                message: "Bank Detail Not Found"
            });

        }
        catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }
}
import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import { CommonConfig } from './config/CommanConfig';
import { MongooseModule } from '@nestjs/mongoose';
import { SettingModule } from './settings/settings.moduel';
import { KycModuel } from './kyc/kyc.module';
import { TransactionsModule } from './transaction/transaction.module';
import { Game_CategoryModule } from './game_category/game_category.module';
import { GamesModule } from './game/game.module';
import { BanckDetailsModule } from './bank_details/bank_details.module';

@Module({
  imports: [ConfigModule.forRoot({
    isGlobal: true
  }),
    MongooseModule.forRootAsync({
      useFactory: async () => ({
        uri: CommonConfig.MONGODB_URL
      })
    }),
  SettingModule,
  KycModuel,
  TransactionsModule,
    Game_CategoryModule,
    GamesModule,
    BanckDetailsModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
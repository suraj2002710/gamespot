import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
export type MainAdminDocument = HydratedDocument<MainAdmin>;

@Schema({})
class Permissions {

    @Prop({ required: true })
    Permission: string;

    @Prop({ required: true })
    Status: boolean;
}

@Schema({ timestamps: true })
export class MainAdmin {
    @Prop()
    role_id: number;

    @Prop()
    roles: string;

    // @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Createor' })
    // created_by: Createor;

    @Prop()
    name: string;

    @Prop({ required: true })
    email: string;

    @Prop()
    profile_pic: string;

    @Prop()
    password: string;

    @Prop()
    phone_country_code: string;

    @Prop()
    phone_number: string;

    @Prop()
    tg_id: string;

    @Prop()
    otp: string;

    @Prop()
    username: string;

    @Prop({ default: 0 })
    status: number; // 0=inactive,1=active 

    @Prop({ type: Permissions })
    Permissions: Permissions;

}

export const MainAdminSchema = SchemaFactory.createForClass(MainAdmin);
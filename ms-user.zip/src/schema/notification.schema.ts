import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

import mongoose, { HydratedDocument } from 'mongoose';
import { Users } from './users.schema';

export type NotificationDocument = HydratedDocument<Notification>;




@Schema({ timestamps: true })
export class Notification {
    @Prop()
    notification_type: String;

    @Prop()
    title: String;

    @Prop()
    body: String;

    @Prop()
    image: String;

    @Prop()
    redirect_path: String;

    @Prop()
    redirect_type: String;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: "User" })
    user_id: Users;


    // @Prop()
    // soundtype: String;

    // @Prop({type: mongoose.Schema.Types.ObjectId,ref:"Users"})
    // sendto_Id:Users ;

    // @Prop()
    // sendto: String;

    // @Prop()
    // msg_type: String;

    // @Prop()
    // other: String;



}

export const NotificationSchema = SchemaFactory.createForClass(Notification);
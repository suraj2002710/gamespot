import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
import { CommonConfig } from 'src/config/CommanConfig';
import { Users } from './users.schema';



export type GamesDocument = HydratedDocument<Games_Challange>;

@Schema({ timestamps: true,  })
export class Games_Challange {
    @Prop({ type: String, required: true })
    Game_type: string;
  
    @Prop({ type: Number, required: true })
    Game_Ammount: number;
  
    @Prop({ type: String, default: null })
    Room_code: string;
  
    @Prop({ type: mongoose.Schema.Types.ObjectId,  ref: 'Users',required: true })
    Created_by: Users;
  
    @Prop({ type: mongoose.Schema.Types.ObjectId,  ref: 'Users'})
    Accepetd_By: Users;
  
    @Prop({ type: Date, default: null })
    Accepetd_At: Date;
  
    @Prop({ type: String, default: null })
    action_by: string;
  
    @Prop({ type: Date, default: null })
    actionby_Date: Date;
  
    @Prop({ type: String, default: 'new' ,enum:["new","running"]})
    Status: string;
  
    @Prop({ type: String, default: null })
    Status_Update_By: string;
  
    @Prop({ type: String, default: null })
    Status_Reason: string;
  
    @Prop({ type: String, default: null })
    Creator_Status: string;
  
    @Prop({ type: String, default: null })
    Creator_Status_Reason: string;
  
    @Prop({ type: String, default: null })
    Creator_Screenshot: string;
  
    @Prop({ type: Date, default: null })
    Creator_Status_Updated_at: Date;
  
    @Prop({ type: String, default: null })
    Acceptor_status: string;
  
    @Prop({ type: String, default: null })
    Acceptor_status_reason: string;
  
    @Prop({ type: String, default: null })
    Acceptor_screenshot: string;
  
    @Prop({ type: Date, default: null })
    Acceptor_status_Updated_at: Date;
  
    @Prop({ type: Date, default: null })
    Acceptor_by_Creator_at: Date;
  
    @Prop({ type: Boolean, default: false })
    Acceptor_seen: boolean;
  
    @Prop({ type: Boolean, default: false })
    Room_join: boolean;
  
    @Prop({ type: String, default: 'active' })
    Room_Status: string;
  
    @Prop({ type: Number, default: null })
    Winner_closingbalance: number;
  
    @Prop({ type: Number, default: null })
    Loser_closingbalance: number;
  
    @Prop({ type: Number, default: null })
    creatorWithdrawDeducted: number;
  
    @Prop({ type: Number, default: null })
    acceptorWithdrawDeducted: number;
  
    @Prop({ type: Number, default: null })
    winnAmount: number;
  
    @Prop({ type: Boolean, default: false })
    lock: boolean;
  
    @Prop({ type: String })
    room_Code_shared: string;

    @Prop({ type: mongoose.Schema.Types.ObjectId,  ref: 'Users'})
    winner: Users;
  
}

export const Games_ChallangeSchema = SchemaFactory.createForClass(Games_Challange);



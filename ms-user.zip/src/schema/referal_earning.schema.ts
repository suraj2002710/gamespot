import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument } from "mongoose";
import { Users } from "./users.schema";

export type RefralEarningDocument = HydratedDocument<RefralEarning>;

@Schema({ timestamps: true })
export class RefralEarning {
    @Prop({ default: 0 })
    amount: string

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: "Users" })
    referral_user: Users

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: "Users" })
    referred_user: Users

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: "Users" })
    deposit_user: Users //deposit user -akshit sir

    @Prop({ default: 0 })
    stage: string
}

export const RefralEarningSchema = SchemaFactory.createForClass(RefralEarning);
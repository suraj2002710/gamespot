import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Users } from "./users.schema";
import mongoose, { HydratedDocument } from "mongoose";

export type KycDocument = HydratedDocument<Kyc>

@Schema()
export class Kyc {

    @Prop({ required: true })
    Name: string;

    @Prop({ required: true })
    Email: string;

    @Prop({ required: true,ref:"Users",type:mongoose.Schema.Types.ObjectId })
    User_Id: Users;

    @Prop({ required: true })
    DOB: string;

    @Prop({ required: true })
    docNumber: string;

    @Prop({ required: true })
    front: string;

    @Prop({ required: true })
    back: string;

    @Prop({ required: true })
    doc_type: String;

    @Prop()
    gender: String;
    
    @Prop()
    address: String;

    @Prop({default: false})
    otpVerified: Boolean;

    @Prop()
    kycOTP: String;
     
    @Prop({ default:'Manual', enum:['Auto', 'Manual'] })
    kycType: String;
    
    @Prop({ default: 'unverified', enum:['unverified', 'Pending' ,'verified']} )
    verified: String;

    @Prop({ default: "" })  //0=pending,1=accpeted 2=rejected
    verified_reason: String;

}

export const KycSchema=SchemaFactory.createForClass(Kyc)
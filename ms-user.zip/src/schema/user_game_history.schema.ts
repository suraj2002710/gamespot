import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

import mongoose, { HydratedDocument } from 'mongoose';
import { Users } from './users.schema';
import { Games } from './games.schema';


export type User_game_HistoryDocument = HydratedDocument<User_game_History>;

@Schema({ timestamps: true })
export class User_game_History {

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true })
    user_id: Users;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Games', required: true })
    ref_id: Games;

    @Prop({ required: true })
    ref_type: string;

}

export const User_game_HistorySchema = SchemaFactory.createForClass(User_game_History);
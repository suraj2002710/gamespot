import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Notification, NotificationSchema } from 'src/schema/notification.schema';
import { Users, UsersSchema } from 'src/schema/users.schema';
import { NotificationController } from './notification.controller';
import { NotificationService } from './notification.service';



@Module({
    imports: [MongooseModule.forFeature([
        { name: Users.name, schema: UsersSchema },
        { name: Notification.name, schema: NotificationSchema },
    ])],
    controllers: [NotificationController],
    providers: [NotificationService]
})
export class NotificationModule { }

import { Injectable } from '@nestjs/common';
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";
import { Notification } from 'src/schema/notification.schema';
import { Users } from 'src/schema/users.schema';
import { CatchErrorResponseHelper, QueryErrorResponseHelper, ResponseHelper } from "src/utils/Response";

@Injectable()
export class NotificationService {

    constructor(
        @InjectModel(Users.name) private readonly Usersservice: Model<Users>,
        @InjectModel(Notification.name) private readonly Notification: Model<Notification>,
    ) { }

    async get_notification(payload: any) {
        try {
            const { page, limit } = payload.body
            let loginUser_id = payload.loginUser?.id
            let skip = (page - 1) * limit
            const findnotification = await this.Notification.find({ user_id: loginUser_id }).sort({ createdAt: -1 }).skip(skip).limit(limit)
            console.log(payload.headers.remote_ip)
            if (findnotification.length) {
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data: findnotification,
                    message: { ip: payload.headers.remote_ip }

                });
            }

            return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                data: [],
                message: "no data found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error);
        }
    }

}

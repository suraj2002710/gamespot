import { Body, Controller } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { NotificationService } from './notification.service';

@Controller()
export class NotificationController {
    constructor(private readonly NotificationService: NotificationService) { }

    @MessagePattern({ cmd: 'get_notification' })
    userTrasactionDepositReq(@Body() payload: any) {
        return this.NotificationService.get_notification(payload)
    }



}

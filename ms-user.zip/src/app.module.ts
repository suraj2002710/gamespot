import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { CommonConfig } from './config/CommanConfig';
import { ReferalModule } from './referal/referal.module';
import { KycModuel } from './kyc/kyc.module';
import { NotificationModule } from './notification/notification.module';
import { BanckDetailsModule } from './bank_details/bank_details.module';
import { SettingModule } from './setting/setting.module';
import { UsersModule } from './Users/users.module';
import { GamesModule } from './games/games.module';


@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal:true
    }),
    MongooseModule.forRootAsync({
      useFactory: async () => ({
        uri: CommonConfig.MONGODB_URL
      })
    }),
    ReferalModule,
    KycModuel,
    NotificationModule,

    BanckDetailsModule,

    SettingModule,
    UsersModule,
    GamesModule,
    UsersModule

  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

import { Module } from '@nestjs/common';
import { SettingController } from './setting.controller';
import { SettingService } from './setting.service';
import { MongooseModule } from "@nestjs/mongoose";
import { Setting, SettingSchema } from "src/schema/setting.schema";
import { Users, UsersSchema } from "src/schema/users.schema";
@Module({
  imports:[MongooseModule.forFeature([
    {name:Setting.name,schema:SettingSchema},
    { name: Users.name, schema: UsersSchema },
])],
  controllers: [SettingController],
  providers: [SettingService]
})
export class SettingModule {}

import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Status, StatusCode } from 'src/constants/HttpConstant';
import { Setting } from 'src/schema/setting.schema';
import { Users } from 'src/schema/users.schema';
import { CatchErrorResponseHelper, ResponseHelper } from 'src/utils/Response';
@Injectable()
export class SettingService {

    constructor(
        @InjectModel(Setting.name)
        readonly SettingModel: Model<Setting>,
        @InjectModel(Users.name) readonly UserModel: Model<Users>,
      ) {}


      async get_setting(payload:any){
        try {
            const setting = await this.SettingModel.findOne();
            if(setting){
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                   data: setting
                  });
            }else{
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                  });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error); 
        }

      }
}

import { Body , Controller } from '@nestjs/common';
import { MessagePattern } from "@nestjs/microservices";
import { SettingService } from './setting.service';

@Controller()
export class SettingController {

    constructor(private readonly settingService: SettingService){}

    @MessagePattern({ cmd:"get_website_setting"})
    async add_bankdetails(@Body() body:any){
        return await this.settingService.get_setting(body)
    }
}

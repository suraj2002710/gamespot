import { Body, Controller } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { Users } from "src/schema/users.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";
import { KycService } from "./kyc.service";
import { MessagePattern } from "@nestjs/microservices";

@Controller()
export class KycController{

    constructor(private readonly KycService:KycService){}

    @MessagePattern({ cmd: 'kyc_request' })
    kyc_request(@Body() payload: any) {
        return this.KycService.kyc_request(payload)
    }

    @MessagePattern({ cmd: 'auto_kyc_generate_otp' })
    auto_kyc_generate_otp(@Body() payload: any) {
        return this.KycService.auto_kyc_generate_otp(payload)
    }
    @MessagePattern({ cmd: 'auto_kyc_otp_verify' })
    auto_kyc_otp_verify(@Body() payload: any) {
        return this.KycService.auto_kyc_otp_verify(payload)
    }
    @MessagePattern({ cmd: 'update_Kyc_request' })
    update_Kyc_request(@Body() payload: any) {
        return this.KycService.update_Kyc_request(payload)
    }
    @MessagePattern({ cmd: 'kyc_request_Otp_verify' })
    kyc_request_Otp_verify(@Body() payload: any) {
        return this.KycService.kyc_request_Otp_verify(payload)
    }

    @MessagePattern({ cmd: "kyc_list" })
    async kyc_list(@Body() body: any) {
        return await this.KycService.kyc_list(body)
    }


    @MessagePattern({ cmd: "kyc_accpect" })
    async kyc_accpect(@Body() body: any) {
        return await this.KycService.kyc_accpect(body)
    }

}
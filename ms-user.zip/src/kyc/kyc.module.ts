import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Users, UsersSchema } from "src/schema/users.schema";
import { KycController } from "./kyc.controller";
import { KycService } from "./kyc.service";
import { Kyc, KycSchema } from "src/schema/kyc.schema";


@Module({
    imports:[MongooseModule.forFeature([
        { name: Users.name, schema: UsersSchema },
        { name: Kyc.name, schema: KycSchema },

    ])],
    providers:[KycService],
    controllers:[KycController]
})
export class KycModuel{}
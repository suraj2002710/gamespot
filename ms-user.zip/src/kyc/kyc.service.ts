import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Status, StatusCode } from 'src/constants/HttpConstant';
import { Kyc } from 'src/schema/kyc.schema';
import { Users } from 'src/schema/users.schema';
import { CatchErrorResponseHelper, ResponseHelper } from 'src/utils/Response';
import { generateOTPPhone } from 'src/utils/Helper';
import axios from 'axios';
import { Payload } from '@nestjs/microservices';
@Injectable()
export class KycService {
  constructor(
    @InjectModel(Users.name) readonly UserModel: Model<Users>,
    @InjectModel(Kyc.name) readonly KycModel: Model<Kyc>,
  ) {}

  async kyc_request(payload: any) {
    try {
      const { DOB, userId, Name, docNumber, doc_type, Email, gender } =
        payload.body;
      const { front, back } = payload.files;
      const loginUser = payload?.loginUser.id;;
      console.log(loginUser)
      const find_user = await this.UserModel.findById(loginUser);
      const find_addhar = await this.KycModel.findOne({ docNumber: docNumber });
      if (find_addhar) {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Aadhar Number already verified with us',
        });
      }

      if (!front || !back) {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'document front and back required',
        });
      }
     
      console.log(find_user , 'kk');
      

      if (find_user && find_user.verified === 'verified') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Your kyc is already verified',
        });
      } else if (find_user && find_user.verified === 'Pending') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Kyc already submitted. Please wait for admin verify',
        });
      }

      if (find_user && find_user.verified === 'unverified') {
        let front_file = front[0];
        let back_file = back[0];

        console.log(front_file, back_file);

        // let doc_front: any = await uploadFile({ file: front_file, destination_folder: "kyc_docs" });
        // let doc_back: any = await uploadFile({ file: back_file, destination_folder: "kyc_docs" });

        let doc_front: any;
        let doc_back: any;
        console.log(doc_front, doc_back, 'file');

        let fronts = '';
        let backs = '';
        if (doc_front?.status) {
          fronts = doc_front?.file_path;
        }

        if (doc_back?.status) {
          backs = doc_back?.file_path;
        }

        const otp = await generateOTPPhone(find_user.phone_number);
        console.log(otp,"otp")
        const createKyc = await this.KycModel.create({
          Name: Name,
          DOB: DOB,
          gender: gender,
          Email: find_user.email,
          docNumber: docNumber,
          doc_type: doc_type,
          verified: 'Pending',
          otpVerified: true,
          front: fronts || "back",
          back: backs || "front" ,
          kycOTP: otp ,
          User_Id: loginUser,
        });

        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          message: 'Please verify otp to complete KYC',
        });
      }
    } catch (error: any) {
      return await CatchErrorResponseHelper(error);
    }
  }

  async auto_kyc_generate_otp(payload: any) {
    try {
      const { docNumber } = payload.body;
      const loginUser = payload?.loginUser;
      let find_user = await this.UserModel.findById(loginUser);
      const alreadyVerify = await this.KycModel.findOne({
        docNumber: docNumber,
      });
      if (alreadyVerify) {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Aadhar Number already verified with us',
        });
      }

    //   if (find_user && find_user.verified === 'verified') {
    //     return await ResponseHelper({
    //       status: Status?.STATUS_TRUE,
    //       status_code: StatusCode?.HTTP_OK,
    //       message: 'Your kyc is already verified',
    //     });
    //   }

      if (find_user && find_user.verified === 'Pending') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Kyc already submitted. Please wait for admin verify',
        });
      } else {
        let datainput = JSON.stringify({
          aadhaar_number: docNumber.toString(),
          consent: 'Y',
        });

        let config = {
          method: 'post',
          maxBodyLength: Infinity,
          url: 'https://api.gridlines.io/aadhaar-api/boson/generate-otp',
          headers: {
            'X-API-Key': 'Sq6cyXCbPihO4X3GfUZxeyrBDrYqT56P',
            'X-Auth-Type': 'API-Key',
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
          data: datainput,
        };

        await axios
          .request(config)
          .then(async (response) => {
            console.log(JSON.stringify(response.data));

            return await ResponseHelper({
              status: Status?.STATUS_TRUE,
              status_code: StatusCode?.HTTP_OK,
              message: 'Data found',
              data: response.data,
            });
          })
          .catch(async (error: any) => {
            console.log(error, 'error');
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'Invalid data',
            });
          });
      }
    } catch (error: any) {
      await CatchErrorResponseHelper(error);
    }
  }

  async auto_kyc_otp_verify(payload: any) {
    try {
      const { docNumber, OTP, userId, transaction_id, Email } = payload.body;
      const loginUser = payload?.loginUser;
      let find_user = await this.UserModel.findById(loginUser);

      if (find_user && find_user.verified === 'pending') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Kyc already submitted. Please wait for verify',
        });
      } else {
        let datainput = JSON.stringify({
          otp: OTP,
          include_xml: true,
          share_code: '1234',
        });

        let config = {
          method: 'post',
          maxBodyLength: Infinity,
          url: 'https://api.gridlines.io/aadhaar-api/boson/submit-otp',
          headers: {
            'X-API-Key': 'Sq6cyXCbPihO4X3GfUZxeyrBDrYqT56P',
            'X-Auth-Type': 'API-Key',
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'X-Transaction-ID': transaction_id,
            Cookie:
              'GCLB=CIaC-crKrPrm1gE; __cf_bm=0aeUBYa7X0b.WfFK0Yg1XR1AAvjNo7XvqF5NLkI8Ckw-1693560552-0-AR1AAhBoQxTTdgaBhRQ0vtBCLABp8OxsopDTQYbKyYQfvSyiodF+lM5/TjtLm1CN8GoF5dC9wcHW7Od/5KkQv1o=',
          },
          data: datainput,
        };

        await axios
          .request(config)
          .then(async (response) => {
            console.log(JSON.stringify(response.data));

            const old_kyc_data = await this.KycModel.updateMany(
                { User_Id: loginUser.id },
                { $set: { verified: 'unverified' } }, // Set the status to "unverified"
              );

            if (response.data.data.aadhaar_data) {
              var aadhardata = response.data.data.aadhaar_data;

              const createKyc = await this.KycModel.create({
                Name: aadhardata.name,
                DOB: aadhardata.date_of_birth,
                gender: aadhardata.gender,
                docNumber: docNumber,
                doc_type: 'Aadhar card',
                verified: 'verified',
                otpVerified: true,
                front: aadhardata.photo_base64,
                back: '',
                User_Id: loginUser?.id,
                address:
                  aadhardata.care_of +
                  ',<br> ' +
                  aadhardata.house +
                  ', ' +
                  aadhardata.street +
                  ', ' +
                  aadhardata.district +
                  ', ' +
                  aadhardata.sub_district +
                  ', ' +
                  aadhardata.landmark +
                  ', ' +
                  aadhardata.locality +
                  ', ' +
                  aadhardata.state +
                  '- ' +
                  aadhardata.pincode +
                  ', ' +
                  aadhardata.country +
                  ', Mo.-' +
                  aadhardata.mobile +
                  ', Email.-' +
                  aadhardata.email,
              });

              find_user.holder_name = aadhardata.name;
              find_user.email = Email;
              find_user.verified = 'verified';
              find_user.save();

              return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                message: 'Your KYC is verified',
                data: createKyc,
              });
            }
          })
          .catch(async (error) => {
            // console.log(error);
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'invalid data',
            });
          });
      }
    } catch (error: any) {
      await CatchErrorResponseHelper(error);
    }
  }

  async update_Kyc_request(payload: any) {
    try {
      const { DOB, Name, docNumber, doc_type, Email, gender } = payload.body;
      const { front, back } = payload.files;
      const loginUser = payload?.loginUser;
      const find_user = await this.UserModel.findById(loginUser?.id);
      const find_addhar = await this.KycModel.findOne({ docNumber: docNumber });
      if (find_addhar) {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Aadhar Number already verified with us',
        });
      }

      if (!front || !back) {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'document front and back required',
        });
      }
      console.log(payload.files);

      if (find_user && find_user.verified === 'unverified') {
        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          message: 'Your kyc is not already verified',
        });
      } else if (find_user && find_user.verified === 'Pending') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Kyc already submitted. Please wait for admin verify',
        });
      }

      if (find_user && find_user.verified === 'verified') {
        let front_file = front[0];
        let back_file = back[0];

        console.log(front_file, back_file);

        // let doc_front: any = await uploadFile({ file: front_file, destination_folder: "kyc_docs" });
        // let doc_back: any = await uploadFile({ file: back_file, destination_folder: "kyc_docs" });

        let doc_front: any;
        let doc_back: any;
        console.log(doc_front, doc_back, 'file');

        let fronts = '';
        let backs = '';
        if (doc_front?.status) {
          fronts = doc_front?.file_path;
        }

        if (doc_back?.status) {
          backs = doc_back?.file_path;
        }

        const otp = await generateOTPPhone(find_user.phone_number);

        const createKyc = await this.KycModel.create({
          Name: Name,
          DOB: DOB,
          gender: gender,
          Email: Email,
          docNumber: docNumber,
          doc_type: doc_type,
          verified: 'Pending',
          otpVerified: true,
          front: fronts,
          back: backs,
          kycOTP: otp,
          User_Id: loginUser?.id,
        });

        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          message: 'Please verify otp to complete KYC',
        });
      }
    } catch (error: any) {
      await CatchErrorResponseHelper(error);
    }
  }

  async kyc_request_Otp_verify(payload: any) {
    try {
      const { OTP } = payload.body;
      const loginUser = payload?.loginUser;
      const find_user = await this.UserModel.findById(loginUser?.id);
      const old_kyc_data = await this.KycModel.updateMany(
        { User_Id: loginUser.id },
        { $set: { verified: 'unverified' } }, // Set the status to "unverified"
      );

      const last_kyc = await this.KycModel.findOne({ User_Id: loginUser.id })
        .sort({ createdAt: -1 })
        .limit(1);

      if (last_kyc && last_kyc.kycOTP == OTP) {
        find_user.verified = 'Pending';
        last_kyc.verified = 'Pending';
        last_kyc.otpVerified = true;
        await last_kyc.save();
        await find_user.save();

        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          message: 'your KYC request submit successfully',
        });
      } else {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Invalid otp',
        });
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }


  // for Admin

  async kyc_list(payload: any) {
    try {
      const { page, limit, filter } = payload.body
      const skip = (page - 1) * limit
      let query: any = {}
      if (filter.length) {
        query.verified = { $in: filter }
      }
      const find_kyc = await this.KycModel.find(query).skip(skip).limit(limit)
      const count = await this.KycModel.countDocuments(query)
      if (find_kyc.length) {
        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          data: { row: find_kyc, count }
        });
      }
      return await ResponseHelper({
        status: Status?.STATUS_FALSE,
        status_code: StatusCode?.HTTP_BAD_REQUEST,
        message: "Data Not Found"
      });
    } catch (error) {
      await CatchErrorResponseHelper(error)
    }
  }



  async kyc_accpect(payload: any) {
    try {

      const { type, id, verified_reason } = payload.body
      console.log(payload.body)
      let verify: any
      if (type == "Pending") {
        verify = "Pending"
      }

      else if (type == "verified") {
        verify = "verified"
      }
      else {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: "invalid type"
        });
      }

      const find_user = await this.KycModel.findOne({ _id: id })
      console.log(find_user, id);

      if (find_user) {
        const update_kyc = await this.KycModel.findByIdAndUpdate({ _id: id }, { $set: { verified: verify, verified_reason: verified_reason, } })

        if (update_kyc) {

          return await ResponseHelper({
            status: Status?.STATUS_TRUE,
            status_code: StatusCode?.HTTP_OK,
            message: verify == "Pending" ? "kyc Pending" : verify == "verified" ? "kyc verified" : "kyc Unverified"
          });
        }
      }

      return await ResponseHelper({
        status: Status?.STATUS_FALSE,
        status_code: StatusCode?.HTTP_BAD_REQUEST,
        data: [],
        message: "no user"
      });


    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }
}

import { CommonConfig } from '../config/CommanConfig';
const http = require('https');

/* ==== Generate user name start ===== */
export const generateUsername = async (payload: any) => {
    var fname = '';
    var lname = '';
    var randomOne = Math.floor(10 + Math.random() * 99);
    var randomTwo = Math.floor(10 + Math.random() * 99);
    if (payload?.fname) {
        fname = payload?.fname;
        fname = fname.replace(/\s/g, '')
            .replace(/^\s+|\s+$/g, '')
            .replace(/[^a-zA-Z ]/g, '')
            .replace(/(?!\w|\s)./g, '')
            .replace(/\s+/g, '');

        fname = fname.substring(0, 3);
    }
    if (payload?.lname) {
        lname = payload?.lname;
        lname = lname.replace(/\s/g, '')
            .replace(/^\s+|\s+$/g, '')
            .replace(/[^a-zA-Z ]/g, '')
            .replace(/(?!\w|\s)./g, '')
            .replace(/\s+/g, '');

        lname = lname.substring(0, 3);
    }
    var userName = fname + lname + randomOne + payload?.id + randomTwo;
    userName = userName.toLowerCase();
    return userName;
}
/* ==== Generate user name end ===== */

export async function generateRandomUsername() {
    let minLength = 6;  // Set the minimum length required
    let length = Math.floor(Math.random() * (10 - minLength + 1) + minLength); // Ensure the length is at least minLength
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let result = "";

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        result += charset.charAt(randomIndex);
    }

    return result;
}

export async function RefralcodeGen() {
    let length = 8;
    const charset = "0123456789";
    let result = "";

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        result += charset.charAt(randomIndex);
    }

    return result;
}
export async function generateOTP() {
    if (CommonConfig?.IS_MAIL_WORKING != '1') {
        return '0000'
    }
    const min = 1000;
    const max = 9999;
    const otp = Math.floor(Math.random() * (max - min + 1)) + min;
    return otp.toString();
}

export async function generateOTPPhone(phone: any) {
    if (CommonConfig?.IS_PHONE_WORKING != '1') {
        return '0000'
    }
    const min = 1000;
    const max = 9999;
    const otp = Math.floor(Math.random() * (max - min + 1)) + min;
    console.log(otp)
    http.get(`https://www.fast2sms.com/dev/bulkV2?authorization=WOhBEQkx2Ruj6nP81ep4cUSwM7fNvy5TYVIAlbrLdgJiFqZKC9D78eTh1drm2kxQR5OWBbMGXwoiyPYH&variables_values=${otp}&route=otp&numbers=${phone}`, (resp: any) => {
        console.log("send");
        return otp.toString();
    })
}

export async function get_uuid(Userserive: any) {
    const find_user = await Userserive.find().sort({ uuid: -1 })
    console.log(find_user[0], "find_user")
    let result = find_user[0]?.uuid ? parseInt(find_user[0]?.uuid?.toString()) + 1 : CommonConfig.UUID_RANDOM_NUMBER
    console.log(result);

    return result;
}
import { Body, Controller } from "@nestjs/common";
import { ReferalService } from "./referal.service";
import { MessagePattern } from '@nestjs/microservices';

@Controller()
export class ReferalController{
    constructor(private readonly ReferalService:ReferalService){}
    
    @MessagePattern({cmd:"referal_code_update"})
    async referal_code_update(@Body() body:any){
        return await this.ReferalService.updateReferal_code(body)
    }

    @MessagePattern({ cmd: 'get_referal_earning' })
    get_referal_earning(@Body() payload: any) {
        return this.ReferalService.get_referal_earning(payload)
    }

    @MessagePattern({ cmd: 'get_referal_history' })
    get_referal_history(@Body() payload: any) {
        return this.ReferalService.get_referal_history(payload)
    }

    @MessagePattern({ cmd: 'reedem' })
    reedem(@Body() payload: any) {
        console.log("user service");
        
        return this.ReferalService.reedem(payload)
    }

}
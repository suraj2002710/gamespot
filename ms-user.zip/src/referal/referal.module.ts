import { Module } from "@nestjs/common";
import { ReferalController } from "./referal.controller";
import { ReferalService } from "./referal.service";
import { MongooseModule } from "@nestjs/mongoose";
import { Users, UsersSchema } from "src/schema/users.schema";
import { RefralEarning, RefralEarningSchema } from "src/schema/referal_earning.schema";


@Module({
    imports:[
    MongooseModule.forFeature([
        {name:Users.name,schema:UsersSchema},
        { name: RefralEarning.name, schema: RefralEarningSchema },
    ])
    ],
    controllers:[ReferalController],
    providers:[ReferalService]
})
export class ReferalModule{}
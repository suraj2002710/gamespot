import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";
import { RefralEarning } from "src/schema/referal_earning.schema";
import { Users } from "src/schema/users.schema";
import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";


@Injectable()
export class ReferalService{
    constructor(@InjectModel(Users.name) readonly UserModel:Model<Users>,
        @InjectModel(RefralEarning.name) private readonly RefralEarning: Model<RefralEarning>,
    ){}

    async updateReferal_code(payload:any){
        try {
            const{referal_code}=payload.body
            const loginUser = payload?.loginUser;
            if(!referal_code){
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `Referal Code ${MessageConstant?.IS_REQUIRED}`,
                });
            }
        
            const find_user=await this.UserModel.findById(loginUser.id)
            if(find_user){
                const update=await this.UserModel.findOneAndUpdate({_id:loginUser.id},{$set:{referral_code:referal_code}})
                if(update){
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `Referal Code ${MessageConstant?.UPDATED_SUCCESS}`,
                    }); 
                }
            }

        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async get_referal_earning(payload: any) {
        try {
            const { user_id, page, limit } = payload.body
            let skip = (page - 1) * limit
            const find_earning = await this.RefralEarning.find({ referred_user: user_id }).populate("referred_user referral_user deposit_user").skip(skip).limit(limit)

            if (find_earning.length) {
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data: find_earning
                });
            }

            return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                data: [],
                message: "no data found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error);
        }
    }

    async get_referal_history(payload: any) {
        try {
            const { user_id, page, limit } = payload.body
            let skip = (page - 1) * limit
            const find_user = await this.UserModel.findOne({ _id: user_id }).skip(skip).limit(limit)

            if (find_user){
                const find_referal_user=await this.UserModel.find({referral_code:find_user?.promo_code})
                if (find_referal_user.length){
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        data: find_referal_user
                    });
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    data: []
                });
            }

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: [],
                message: "no user found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error);
        }
    }

    async reedem(payload: any) {
        try {
            const { amount } = payload.body
            const loginUser = payload?.loginUser ; 
            
            const find_user = await this.UserModel.findOne({ _id: loginUser?.id })
            console.log(loginUser, find_user);


            if (find_user){

                if (find_user.referal_wallet_amt >= amount){
                    let new_referal_amt=parseInt(find_user.referal_wallet_amt.toString())-amount
                    let new_wallet_amt = parseInt(find_user.Wallet_balance.toString()) + amount
                    await this.UserModel.findByIdAndUpdate({_id:loginUser?.id},{$set:{Wallet_balance:new_wallet_amt,referal_wallet_amt:new_referal_amt}})
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: "Referal Wallet Amount Tranasfer Your WalletAmount"
                    }); 
                }
              
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message:"Referal Wallet Amount Less Than Your Amount"
                    });
              
            }

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: [],
                message: "no user found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error);
        }
    }
}
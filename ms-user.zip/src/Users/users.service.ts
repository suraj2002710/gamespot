import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import mongoose, { Model } from "mongoose";
import { CommonConfig } from "src/config/CommanConfig";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";
import { Games } from "src/schema/games.schema";
import { Games_Challange } from "src/schema/games_challange.schema";
import { RefralEarning } from "src/schema/referal_earning.schema";
import { Users } from "src/schema/users.schema";
import { CatchErrorResponseHelper, QueryErrorResponseHelper, ResponseHelper } from "src/utils/Response";


@Injectable()
export class UsersService{
    constructor(
        @InjectModel(Users.name) readonly Usersmodle:Model<Users>,
        @InjectModel(Games_Challange.name) readonly Games_Challangemodle:Model<Games_Challange>,
        @InjectModel(RefralEarning.name) readonly RefralEarningmodle:Model<RefralEarning>
    ){}
 
    async otherDetails(payload: any) {
        try {
            const loginUser = payload?.loginUser ; 
            const win_amount = await this.Games_Challangemodle.aggregate([
                { $match: { winner: new mongoose.Types.ObjectId(loginUser.id) } },
                { $group: { _id: null, totalWinAmount: { $sum: '$Game_Ammount' } } }
              ]);

              console.log(loginUser.id,await this.Games_Challangemodle.find({Accepetd_By:loginUser.id}))
              let battle_count = await this.Games_Challangemodle.countDocuments({
                $or: [
                  { Created_by: loginUser.id },
                  { Accepetd_By: loginUser.id}
                ]
              });

              let referal_count = await this.RefralEarningmodle.countDocuments({
                   referred_user: loginUser.id
              });

            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                data: {referal_count,battle_count,win_amount:win_amount[0]?.totalWinAmount},
                message: "no user found"
            });
        } catch (error) {
            await CatchErrorResponseHelper(error);
        }
    }
}
import { Body, Controller } from "@nestjs/common";
import { UsersService } from "./users.service";
import { MessagePattern } from "@nestjs/microservices";


@Controller()
export class UsersController{
    constructor(private readonly Userservice:UsersService ){}

    @MessagePattern({cmd:"other_details"})
    async referal_code_update(@Body() body:any){
        return await this.Userservice.otherDetails(body)
    }
 
}
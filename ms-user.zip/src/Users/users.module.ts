import { Module } from "@nestjs/common";
import { UsersService } from "./users.service";
import { UsersController } from "./users.controller";
import { MongooseModule } from "@nestjs/mongoose";
import { Users, UsersSchema } from "src/schema/users.schema";
import { RefralEarning, RefralEarningSchema } from "src/schema/referal_earning.schema";
import { Games, GamesSchema } from "src/schema/games.schema";
import { Games_Challange, Games_ChallangeSchema } from "src/schema/games_challange.schema";


@Module({
    imports:[
        MongooseModule.forFeature([
            {name:Users.name,schema:UsersSchema},
            { name: RefralEarning.name, schema: RefralEarningSchema },
            { name: Games_Challange.name, schema: Games_ChallangeSchema }
        ])
    ],
    controllers:[UsersController],
    providers:[UsersService]
})
export class UsersModule{}
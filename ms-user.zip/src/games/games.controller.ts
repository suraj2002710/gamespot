import { Controller } from '@nestjs/common';

@Controller('games')
export class GamesController {}

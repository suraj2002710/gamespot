import { Body, Controller } from "@nestjs/common";
import { Model } from "mongoose";
import { BanckDetailsServicse } from "./bank_details.service";
import { MessagePattern } from "@nestjs/microservices";


@Controller()
export class BanckDetailsController{
    constructor(private readonly BanckDetailsServicse:BanckDetailsServicse){}

    @MessagePattern({ cmd:"add_bank_details"})
    async add_bankdetails(@Body() body:any){
        return await this.BanckDetailsServicse.add_bank_details(body)
    }

    @MessagePattern({ cmd:"bank_Otp_verify"})
    async bank_Otp_verify(@Body() body:any){
        return await this.BanckDetailsServicse.bank_Otp_verify(body)
    }

    @MessagePattern({ cmd:"get_bank_and_upisDetails"})
    async get_bank_and_upisDetails(@Body() body:any){
        return await this.BanckDetailsServicse.get_bank_and_upisDetails(body)
    }
    
}
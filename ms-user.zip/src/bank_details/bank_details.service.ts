import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Status, StatusCode } from 'src/constants/HttpConstant';
import { BanckDetails } from 'src/schema/bank_details.schema';
import { Users } from 'src/schema/users.schema';
import { CatchErrorResponseHelper, ResponseHelper } from 'src/utils/Response';
import { generateOTPPhone } from 'src/utils/Helper';

@Injectable()
export class BanckDetailsServicse {
  constructor(
    @InjectModel(BanckDetails.name)
    readonly BankModel: Model<BanckDetails>,
    @InjectModel(Users.name) readonly UserModel: Model<Users>,
  ) { }

  async add_bank_details(payload: any) {
    try {
      const {
        accountNumber,
        bankName,
        ifsc_code,
        branch_name,
        type,
        upi,
        account_holder_name,
      } = payload.body;
      const loginUser = payload?.loginUser;
      const find_user = await this.UserModel.findById(loginUser?.id);
      console.log(payload.body);
      if (find_user) {

        const otp = await generateOTPPhone(find_user.phone_number);
        console.log("otp",otp)

        const create_bank_details = await this.BankModel.create({
          accountNumber,
          bankName,
          ifsc_code,
          branch_name,
          type,
          upi,
          User_Id: loginUser.id,
          account_holder_name,
          bankOTP: otp,
        });

        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          message: 'Please verify otp to add bank detail',
        });
      }

    } catch (error: any) {
      await CatchErrorResponseHelper(error);
    }
  }
  //   async update_bank_details(payload: any) {
  //     try {
  //       const {
  //         accountNumber,
  //         bankName,
  //         ifsc_code,
  //         branch_name,
  //         type,
  //         upi,
  //         confirm_account,
  //         confirm_upi,
  //         account_holder_name,
  //       } = payload.body;
  //       const loginUser = payload?.loginUser;
  //       console.log(payload.body);
  //       if (accountNumber !== confirm_account) {
  //         return await ResponseHelper({
  //           status: Status?.STATUS_TRUE,
  //           status_code: StatusCode?.HTTP_OK,
  //           message: 'AccountNumber And Confirm AccountNumber Dose Not Match',
  //         });
  //       }

  //       const create_bank_details = await this.BankModel.create({
  //         accountNumber,
  //         bankName,
  //         ifsc_code,
  //         branch_name,
  //         type,
  //         upi,
  //         confirm_account,
  //         confirm_upi,
  //         User_Id: loginUser.id,
  //         account_holder_name,
  //       });
  //       console.log(create_bank_details);

  //       return await ResponseHelper({
  //         status: Status?.STATUS_TRUE,
  //         status_code: StatusCode?.HTTP_OK,
  //         message: 'Bank Detail add successfully',
  //       });
  //     } catch (error: any) {
  //       await CatchErrorResponseHelper(error);
  //     }
  //   }

  async bank_Otp_verify(payload: any) {
    try {
      const { OTP } = payload.body;
      const loginUser = payload?.loginUser;
      const find_user = await this.UserModel.findById(loginUser?.id);
      if (find_user) {
        const old_bank_data = await this.BankModel.updateMany(
          { User_Id: loginUser.id },
          { $set: { verified: 'unverified' } }, // Set the status to "unverified"
        );

        const last_bank = await this.BankModel.findOne({ User_Id: loginUser.id })
          .sort({ createdAt: -1 })
          .limit(1);

        if (last_bank && last_bank.bankOTP == OTP) {
          find_user.account_number = last_bank.accountNumber;
          find_user.ifsc_code = last_bank.ifsc_code;
          find_user.holder_name = last_bank.account_holder_name;
          last_bank.verified = 'verified';
          last_bank.otpVerified = true;
          await last_bank.save();
          await find_user.save();

          return await ResponseHelper({
            status: Status?.STATUS_TRUE,
            status_code: StatusCode?.HTTP_OK,
            message: 'Bank Detail add successfully',
            data:last_bank
          });
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: 'Invalid otp',
          });
        }
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }


  async get_bank_and_upisDetails(payload: any) {
    try {
      const {type}=payload.body
      const loginUser = payload?.loginUser;
      const find_user = await this.BankModel.findOne({User_Id:loginUser?.id,type});
      
      
      
        

          return await ResponseHelper({
            status: Status?.STATUS_TRUE,
            status_code: StatusCode?.HTTP_OK,
            data:{detail:find_user,type}
          });
        
          
        
      
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }
}

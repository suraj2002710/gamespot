import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { BanckDetails, BanckDetailsSchema } from "src/schema/bank_details.schema";
import { BanckDetailsController } from "./bank_details.controller";
import { BanckDetailsServicse } from "./bank_details.service";
import { Users, UsersSchema } from "src/schema/users.schema";

@Module({
    imports:[MongooseModule.forFeature([
        {name:BanckDetails.name,schema:BanckDetailsSchema},
        { name: Users.name, schema: UsersSchema },
    ])],
    controllers:[BanckDetailsController],
    providers:[BanckDetailsServicse]
})
export class BanckDetailsModule{}
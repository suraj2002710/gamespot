import { Body, Controller } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";

import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";

import { MessagePattern } from "@nestjs/microservices";
import { UserContestService } from "./user.contest.service";


@Controller()
export class UserContestController{

    constructor(private readonly UserContestService:UserContestService){}

    @MessagePattern({ cmd: 'get_user_tournaments' })
    get_tournaments(@Body() payload: any) {
        return this.UserContestService.get_tournaments(payload)
    }

    @MessagePattern({ cmd: 'GetPlayer' })
    GetPlayer(@Body() payload: any) {
        return this.UserContestService.GetPlayer(payload)
    }

    @MessagePattern({ cmd: 'createUserTeam' })
    createTeam(@Body() payload: any) {
        return this.UserContestService.createUserTeam(payload)
    }

    @MessagePattern({ cmd: 'GetMatchs' })
    GetMatchs(@Body() payload: any) {
        return this.UserContestService.GetMatchs(payload)
    }
}
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Status, StatusCode } from 'src/constants/HttpConstant';

import { CatchErrorResponseHelper, ResponseHelper } from 'src/utils/Response';
import { generateOTPPhone } from 'src/utils/Helper';

import { Payload } from '@nestjs/microservices';
import { Users } from 'src/schema/user.schema';
import { Tournaments } from 'src/schema/tournaments.schema';
import { ContestType } from 'src/schema/contest_type.schema';
import { Team } from 'src/schema/team.schema';
import { UserTeam } from 'src/schema/userTeam.schema';
import { Player } from 'src/schema/player.schema';
import { PlayerScore } from 'src/schema/playerScore.schema';
import { Match } from 'src/schema/matchs.schema';
@Injectable()
export class UserContestService {
  constructor(
    @InjectModel(Users.name) readonly UserModel: Model<Users>,
    @InjectModel(Tournaments.name) readonly TournamentsModel: Model<Tournaments>,
    @InjectModel(ContestType.name) readonly ContestTypeModel: Model<ContestType>,
    @InjectModel(Team.name) readonly TeamModel: Model<Team>,
    @InjectModel(UserTeam.name) readonly UserTeamModel: Model<UserTeam>,
    @InjectModel(Player.name) readonly PlayerModel: Model<Player>,
    @InjectModel(PlayerScore.name) readonly PlayerScoreModel: Model<PlayerScore>,
    @InjectModel(Match.name) readonly MatchModel: Model<Match>,
  ) {
  }
  async get_tournaments(payload: any) {
    try {
        const { page, limit,match_id} = payload.body
        let loginUser_id = payload.loginUser?.id
        let skip = (page - 1) * limit
        // const findtournaments = await this.TournamentsModel.aggregate([
        //   {
        //     $group: {
        //       _id: "$contest_type", // Group by contest_type
        //       count: { $sum: 1 }, // Count the number of tournaments in each group
        //       averagePrizePool: { $avg: "$prize_pool" }, // Calculate the average prize pool for each group
        //       tournaments: {
        //         $push: {
        //           _id: "$_id",
        //           creator: "$creator",
        //           prize_pool: "$prize_pool",
        //           entry_fee: "$entry_fee",
        //           first_prize: "$first_prize",
        //           winner_percentage: "$winner_percentage",
        //           total_spot: "$total_spot",
        //           participants: "$participants",
        //           match_id: "$match_id",
        //           winning_price_rankWise: "$winning_price_rankWise"
        //         }
        //       }
        //     }
        //   },
        //   {
        //     $lookup: {
        //       from: 'ContestType', // Collection name of contest types
        //       localField: '_id',
        //       foreignField: 'contest_type',
        //       as: 'contest_type_details'
        //     }
        //   },
        //   {
        //     $unwind: '$contest_type_details'
        //   },
        //   {
        //     $project: {
        //       _id: 0,
        //       contest_type: '$contest_type_details.name',
        //       count: 1,
        //       averagePrizePool: 1,
        //       tournaments: 1
        //     }
        //   }
        // ])
        
        const findtournaments=await this.TournamentsModel.aggregate([
          // {
          //   $match:{
          //     match_id:match_id
          //   }
          // },
          {
            $group: {
              _id: "$contest_type",
              tournaments: { $push: "$$ROOT" },
              count: { $sum: 1 },
            },
          },
          {
            $lookup: {
              from: "contesttypes", // The name of the contest type collection
              localField: "_id",
              foreignField: "_id",
              as: "contest_type_details",
            },
          },
          {
            $unwind: "$contest_type_details",
          },
        ]).exec();

        if (findtournaments.length) {
            return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                data: findtournaments,
                message: { ip: payload.headers.remote_ip }

            });
        }

        return await ResponseHelper({
            status: Status?.STATUS_TRUE,
            status_code: StatusCode?.HTTP_OK,
            data: [],
            message: "no data found"
        });
    } catch (error) {
        await CatchErrorResponseHelper(error);
    }
}



//   Create User Team

async createUserTeam(payload: any) {
    try {
      const { contest_id, players, captain_id, vice_captain_id } = payload.body;
      let loginUser_id = payload.loginUser?.id
      const createdUserTeam = await this.UserTeamModel.create({
        user_id:loginUser_id,
        contest_id,
        players,
        captain_id,
        vice_captain_id,
      });

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createdUserTeam,
        message: "Team created successfully",
    });

    } catch (error) {
        await CatchErrorResponseHelper(error);
    }
  }


  // get Player
async GetPlayer(payload: any) {
  try {
    const { team_id,role } = payload.body;
    const createdPlayer = await this.PlayerModel.find({ team_id:{$in:team_id},role });

    return await ResponseHelper({
      status: Status?.STATUS_TRUE,
      status_code: StatusCode?.HTTP_OK,
      data: createdPlayer,
      message: "Player created successfully",
  });

    
  } catch (error) {
      await CatchErrorResponseHelper(error);
  }
}


async GetMatchs(payload: any) {
  try {
    const {  } = payload.body;
    const getmatch = await this.MatchModel.find({ }).populate("team1_id").populate("team2_id");

    return await ResponseHelper({
      status: Status?.STATUS_TRUE,
      status_code: StatusCode?.HTTP_OK,
      data: getmatch,
      message: "fetch successfully",
  });

    
  } catch (error) {
      await CatchErrorResponseHelper(error);
  }
}
}

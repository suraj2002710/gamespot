import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

export type PlayerScoreDocument = HydratedDocument<PlayerScore>;

@Schema({ timestamps: true })
export class PlayerScore {
  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Match', required: true })
  match_id: mongoose.Schema.Types.ObjectId;

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true })
  player_id: mongoose.Schema.Types.ObjectId;

  @Prop({ required: true })
  runs: number;

  @Prop({ required: true })
  wickets: number;

  @Prop({ required: true })
  catches: number;

  @Prop({ required: true })
  points: number;
}

export const PlayerScoreSchema = SchemaFactory.createForClass(PlayerScore);

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
import { ContestType } from './contest_type.schema';
import { Users } from './user.schema';

// import { Admin } from '../schemas/admins.schema';

export type TournamentsDocument = HydratedDocument<Tournaments>;

@Schema({ timestamps: true })
export class Tournaments {
    @Prop({required:true, type: mongoose.Schema.Types.ObjectId, ref: 'Users' } )
    creator : Users;

    @Prop({required:true})
    prize_pool : number;
    
    @Prop({required:true,type:mongoose.Schema.Types.ObjectId,ref:"ContestType"})
    contest_type : ContestType;
    

    @Prop({required:true})
    entry_fee : number;

    @Prop({required:true})
    first_prize : number;

    @Prop({required:true})
    winner_percentage : number;     

    @Prop({required:true})
    total_spot : number;
    
    @Prop({required:true,type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Users' }] })
    participants : Users[];  

    @Prop({required:true})
    match_id : number;   
 
    @Prop()                
    winning_price_rankWise : [{
        rank:string,
        winningAmount:number
    }]


}


export const TournamentsSchema = SchemaFactory.createForClass(Tournaments);
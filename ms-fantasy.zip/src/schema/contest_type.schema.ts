import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

// import { Admin } from '../schemas/admins.schema';

export type contestTypeDocument = HydratedDocument<ContestType>;

@Schema({ timestamps: true })
export class ContestType {
    @Prop({required:true})
    contestType : string;

}


export const ContestTypeSchema = SchemaFactory.createForClass(ContestType);
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

export type TeamDocument = HydratedDocument<Team>;

@Schema({ timestamps: true })
export class Team {
  @Prop({ required: true })
  team_name: string;

  @Prop({ required: true })
  unique_id: string;

  @Prop({ required: true })
  team_short_name: string;

  @Prop({ default: 'uploads/team_default.png' })
  team_image: string;
}

export const TeamSchema = SchemaFactory.createForClass(Team);

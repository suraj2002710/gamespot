import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

export type MatchDocument = HydratedDocument<Match>;

@Schema({ timestamps: true })
export class Match {
  @Prop({ required: true })
  unique_id: number; // Changed from 'Number' to 'number' for TypeScript type

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true })
  teamid1: mongoose.Schema.Types.ObjectId; // Renamed from 'team1_id'

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true })
  teamid2: mongoose.Schema.Types.ObjectId; // Renamed from 'team2_id'

  @Prop({ required: true })
  type: string; // Added 'type' field

  @Prop({ required: true })
  title: string; // Added 'title' field

  @Prop({ required: true })
  time: string; // Changed to string to store ISO date string

  @Prop({ required: true })
  match_status: string; // Added 'match_status' field

  @Prop({ required: true })
  league_name: string; // Added 'league_name' field

  @Prop({ required: true })
  created_date: Date; // Added 'created_date' field

  @Prop({ required: true })
  match_date_time: Date; // Added 'match_date_time' field

  @Prop({ })
  start_time: Date; // Retained 'start_time' field

  @Prop({ })
  end_time: Date; // Retained 'end_time' field
}

export const MatchSchema = SchemaFactory.createForClass(Match);

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

export type PlayerDocument = HydratedDocument<Player>;

@Schema({ timestamps: true })
export class Player {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  bats: string;

  @Prop({ required: true })
  bowls: string;

  @Prop({ required: true })
  dob: Date;

  @Prop({  })
  nationality: string;

  @Prop({ required: true })
  pid: string;

  @Prop({ required: true })
  credit_points: number;

  @Prop({ required: true })
  designationid: string;

  @Prop({ required: true })
  created_date: Date;

  @Prop({ required: true, type: mongoose.Schema.Types.ObjectId, ref: 'Team' })
  teamid: string;

  @Prop({ required: true })
  image: string;
}

export const PlayerSchema = SchemaFactory.createForClass(Player);

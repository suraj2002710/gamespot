import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

export type UserTeamDocument = HydratedDocument<UserTeam>;

@Schema({ timestamps: true })
export class UserTeam {
  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true })
  user_id: mongoose.Schema.Types.ObjectId;

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Tournaments', required: true })
  contest_id: mongoose.Schema.Types.ObjectId;

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Player' }], required: true })
  players: mongoose.Schema.Types.ObjectId[];

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true })
  captain_id: mongoose.Schema.Types.ObjectId;

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true })
  vice_captain_id: mongoose.Schema.Types.ObjectId;
}

export const UserTeamSchema = SchemaFactory.createForClass(UserTeam);

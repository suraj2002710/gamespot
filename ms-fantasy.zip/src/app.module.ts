import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { CommonConfig } from './config/CommanConfig';
import { TournamentsModuel } from './tournaments/tournaments.module';
import { UserContestModuel } from './user_contest/user_contest.module';



@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal:true
    }),
    MongooseModule.forRootAsync({
      useFactory: async () => ({
        uri: CommonConfig.MONGODB_URL
      })
    }),
    TournamentsModuel,
    UserContestModuel

  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

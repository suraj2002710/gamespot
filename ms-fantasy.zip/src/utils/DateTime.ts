import * as moment from 'moment';
import 'moment-timezone';
import { CommonConfig } from '../config/CommanConfig';

/* ==== Get time zone to utc start ===== */
export const getTimeZoneToUtc = async (datetime: string, datetime_format: any, timezone: string) => {
    const get_datetime = moment.tz(`${datetime}`, `${datetime_format}`, timezone).utc().format(CommonConfig?.DATE_TIME_FORMATE);
    return get_datetime;
}
/* ==== Get time zone to utc end ===== */

/* ==== Match date time from database start ===== */
export const MatchDBDateTimeHelper = async (datetime: any)=>{
    if (datetime && datetime != null) {
        return moment(new Date(datetime));
    } else {
        return moment().utc().format(CommonConfig?.DATE_TIME_FORMATE);
    }
}
/* ==== Match date time from database end ===== */

/* ==== Insert date time from database start ===== */
export const InsertDBDateTimeHelper = async (datetime: any, is_server_time: any = true) => {
    if (datetime && datetime != null) {
        if (!is_server_time) {
            let timezone = `${CommonConfig?.DEFAULT_TIMEZONE}`;

            const datetime_format = CommonConfig?.DATE_TIME_FORMATE;
            return await getTimeZoneToUtc(datetime, datetime_format, timezone);
        }
        else {
            return await moment(datetime).format(CommonConfig?.DATE_TIME_FORMATE);
        }
    } else {
        return moment().utc().format(CommonConfig?.DATE_TIME_FORMATE);
    }
}
/* ==== Insert date time from database end ===== */

/* ==== Get date from database start ===== */
export const GetDBDateTimeHelper = (datetime: any) => {
    if (datetime && datetime != null) {
        return moment(datetime);
    } else {
        return null;
    }
}
/* ==== Get date from database end ===== */

/* ==== Get current date time start ===== */
export const GetCurrentDateTimeHelper = async () => {
    return moment().utc();
}
/* ==== Get current date time rnd ===== */

/* ==== Add minutes date time start ===== */
export const AddMinutesHelper = async (datetime: any, minute: number) => {
    if (datetime && datetime != null && minute) {
        return moment(datetime).add(minute, 'minutes');
    } else {
        return null;
    }
}
/* ==== Add minutes date time end ===== */

/* ==== Add hours date time start ===== */
export const AddHoursHelper = async (datetime: any, hours: number) => {
    if (datetime && datetime != null && hours) {
        return moment(datetime).add(hours, 'hours');
    } else {
        return null;
    }
}
/* ==== Add hours date time end ===== */

/* ==== Add days date time start ===== */
export const AddDaysHelper = async (datetime: any, days: number) => {
    if (datetime && datetime != null && days) {
        return moment(datetime).add(days, 'days');
    } else {
        return null;
    }
}
/* ==== Add days date time end ===== */

/* ==== Add months date time start ===== */
export const AddMonthsHelper = async (datetime: any, months: number) => {
    if (datetime && datetime != null && months) {
        return moment(datetime).add(months, 'months');
    } else {
        return null;
    }
}
/* ==== Add months date time end ===== */

/* ==== Add years date time start ===== */
export const AddYearsHelper = async (datetime: any, years: number) => {
    if (datetime && datetime != null && years) {
        return moment(datetime).add(years, 'years');
    } else {
        return null;
    }
}
/* ==== Add years date time end ===== */


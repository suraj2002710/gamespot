import { Body, Controller } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Status, StatusCode } from "src/constants/HttpConstant";

import { CatchErrorResponseHelper, ResponseHelper } from "src/utils/Response";

import { MessagePattern } from "@nestjs/microservices";
import { TournamentService } from "./tournaments.service";

@Controller()
export class TournamentsController{

    constructor(private readonly TournamentService:TournamentService){}

    @MessagePattern({ cmd: 'get_tournaments' })
    get_tournaments(@Body() payload: any) {
        return this.TournamentService.get_tournaments(payload)
    }

    @MessagePattern({ cmd: 'create_tournaments' })
    create_tournaments(@Body() payload: any) {
        return this.TournamentService.create_tournaments(payload)
    }

    @MessagePattern({ cmd: 'create_contestType' })
    create_contestType(@Body() payload: any) {
        return this.TournamentService.create_contestType(payload)
    }

    @MessagePattern({ cmd: 'createMatch' })
    createMatch(@Body() payload: any) {
        return this.TournamentService.createMatch(payload)
    }

    @MessagePattern({ cmd: 'createPlayerScore' })
    createPlayerScore(@Body() payload: any) {
        return this.TournamentService.createPlayerScore(payload)
    }

    @MessagePattern({ cmd: 'createPlayer' })
    createPlayer(@Body() payload: any) {
        return this.TournamentService.createPlayer(payload)
    }

    

    @MessagePattern({ cmd: 'createTeam' })
    createTeam(@Body() payload: any) {
        return this.TournamentService.createTeam(payload)
    }

    @MessagePattern({ cmd: 'fetchAndStoreMatches' })
    fetchAndStoreMatches(@Body() payload: any) {
        return this.TournamentService.fetchAndStoreMatches(payload)
    }
}
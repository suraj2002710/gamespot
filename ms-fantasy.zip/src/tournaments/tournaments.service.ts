import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Status, StatusCode } from 'src/constants/HttpConstant';
import axios from "axios"
import { CatchErrorResponseHelper, ResponseHelper } from 'src/utils/Response';
import { generateOTPPhone } from 'src/utils/Helper';

import { Payload } from '@nestjs/microservices';
import { Users } from 'src/schema/user.schema';
import { Tournaments } from 'src/schema/tournaments.schema';
import { ContestType } from 'src/schema/contest_type.schema';
import { Team } from 'src/schema/team.schema';
import { UserTeam } from 'src/schema/userTeam.schema';
import { Player } from 'src/schema/player.schema';
import { PlayerScore } from 'src/schema/playerScore.schema';
import { Match } from 'src/schema/matchs.schema';
@Injectable()
export class TournamentService {
  private readonly apiUrl = 'https://cricket.sportmonks.com/api/v2.0';
  private readonly apiToken = 'M2cDm4PXU3ZsgTfmrNHkzYvtxBbtqFsw1HqTAu4SruoFfPJ9poFDN8ejIKCY';
  constructor(
    @InjectModel(Users.name) readonly UserModel: Model<Users>,
    @InjectModel(Tournaments.name) readonly TournamentsModel: Model<Tournaments>,
    @InjectModel(ContestType.name) readonly ContestTypeModel: Model<ContestType>,
    @InjectModel(Team.name) readonly TeamModel: Model<Team>,
    @InjectModel(UserTeam.name) readonly UserTeamModel: Model<UserTeam>,
    @InjectModel(Player.name) readonly playerModel: Model<Player>,
    @InjectModel(PlayerScore.name) readonly PlayerScoreModel: Model<PlayerScore>,
    @InjectModel(Match.name) readonly MatchModel: Model<Match>,


  ) {
  }
  async get_tournaments(payload: any) {
    try {
      const { page, limit, match_id } = payload.body
      let loginUser_id = payload.loginUser?.id
      let skip = (page - 1) * limit
      const findtournaments = await this.TournamentsModel.find({ match_id }).populate("contest_type").sort({ createdAt: -1 }).skip(skip).limit(limit)

      if (findtournaments.length) {
        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          data: findtournaments,
          message: { ip: payload.headers.remote_ip }

        });
      }

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: [],
        message: "no data found"
      });
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async create_tournaments(payload: any) {
    try {
      const { prize_pool, contest_type, entry_fee, first_prize, winner_percentage, total_spot, match_id, winning_price_rankWise } = payload.body
      let loginUser_id = payload.loginUser?.id
      const createtournaments = await this.TournamentsModel.create({ prize_pool, contest_type, entry_fee, first_prize, winner_percentage, total_spot, match_id, winning_price_rankWise, creator: loginUser_id })


      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createtournaments,
        message: "TournaMent create Successfully"

      });

    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async create_contestType(payload: any) {
    try {
      const { contestType } = payload.body
      let loginUser_id = payload.loginUser?.id
      const createtournaments = await this.ContestTypeModel.create({ contestType })

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createtournaments,
        message: "TournaMent create Successfully"
      });

    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }



  // Create Player
  async createPlayer(payload: any) {
    try {
      const { name, team_id, role } = payload.body;
      const createdPlayer = await this.playerModel.create({ name, team_id, role });

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createdPlayer,
        message: "Player created successfully",
      });


    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  // Create Team
  async createTeam(payload: any) {
    try {
      const { name } = payload.body;
      const createdTeam = await this.TeamModel.create({ name });

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createdTeam,
        message: "Team created successfully",
      });

    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  //   Create match api

  async createMatch(payload: any) {
    try {
      const { team1_id, team2_id, start_time, end_time } = payload.body;
      const createdMatch = await this.MatchModel.create({ team1_id, team2_id, start_time, end_time });

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createdMatch,
        message: "Match created successfully",
      });

    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }



  async fetchAndStoreMatches(payload:any) {
    const {matches}=payload.body
    // const startDate = new Date().toISOString().split('T')[0];
    // const endDate = new Date(new Date().getTime() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    // console.log(startDate, endDate)
    // const url = `${this.apiUrl}/fixtures?api_token=${this.apiToken}&filter[starts_between]=${"2024-05-1"},${endDate}&include=league,localteam,visitorteam,league`;
    // console.log(url)
    // const response = await axios.get(url)
    // const matches = response.data?.data;


    for (const item of matches) {
      if (item.status === 'Finished' && ['Test', 'T20I', 'T20', 'Woman ODI', 'Test/5day', 'Test/4day', 'ODI'].includes(item.type)) {
        // console.log(item,"item")
        const mainTime = new Date(item.starting_at);
        const timeInIST = new Date(mainTime.getTime() + (330 * 60 * 1000)); // Convert GMT to IST (GMT+5:30)

        if (timeInIST >= new Date()) {
          let team1 = await this.TeamModel.findOne({ unique_id: item.localteam_id }).exec();
          if (!team1) {
            const team1Data = {
              team_name: item.localteam.name,
              unique_id: item.localteam.id,
              team_short_name: item.localteam.code,
              team_image: item.localteam.image_path || 'uploads/team_default.png',
            };
            team1 = new this.TeamModel(team1Data);
            await team1.save();
            console.log("team1", team1)
          }

          let team2 = await this.TeamModel.findOne({ unique_id: item.visitorteam_id }).exec();
          if (!team2) {
            const team2Data = {
              team_name: item.visitorteam.name,
              unique_id: item.visitorteam.id,
              team_short_name: item.visitorteam.code,
              team_image: item.visitorteam.image_path || 'uploads/team_default.png',
            };
            team2 = new this.TeamModel(team2Data);
            await team2.save();
            console.log("team2", team2)
          }

          const matchType = ['Test/5day', 'Test/4day'].includes(item.type) ? 'Test' : item.type;

          const matchData: {} = {
            unique_id: item.id,
            teamid1: team1._id,
            teamid2: team2._id,
            type: matchType,
            title: `${item.localteam.name} vs ${item.visitorteam.name}`,
            time: timeInIST.toISOString(),
            match_status: 'Fixture',
            league_name: item.league.name,
            created_date: new Date(),
            match_date_time: timeInIST,
          };

          const existingMatch = await this.MatchModel.findOne({ unique_id: item.id }).exec();
          if (!existingMatch) {
            const newMatch: any = new this.MatchModel(matchData);
            await newMatch.save();
            await this.fetchAndStoreTeams(item.localteam_id, item.season_id, newMatch._id);
            await this.fetchAndStoreTeams(item.visitorteam_id, item.season_id, newMatch._id);
            // Add contests (omitted for brevity)
          }
        }
      }
    }

    return await ResponseHelper({
      status: Status?.STATUS_TRUE,
      status_code: StatusCode?.HTTP_OK,
      data: matches,
      message: "Matchc fetch Successfully",
    });
  }

  private async fetchAndStoreTeams(teamId: number, seasonId: number, matchId: string): Promise<void> {
    const url = `${this.apiUrl}/teams/${teamId}/squad/${seasonId}?api_token=${this.apiToken}`;
    const response = await axios.get(url)
    console.log(url,"urlpalyer")
    const players = response.data.data.squad;

    for (const player of players) {
      const team = await this.TeamModel.findOne({ unique_id: response.data.id }).exec();
      let existingPlayer = await this.playerModel.findOne({ pid: player.id }).exec();

      const playingRoleMap = {
        Bowler: 2,
        Batsman: 1,
        Wicketkeeper: 4,
        Allrounder: 3,
      };

      const role = playingRoleMap[player.position.name] || 3;
      const playersImage = player.image_path.includes('cricket/players') ? player.image_path : 'uploads/player/default.png';

      if (!existingPlayer) {
        const playerData = {
          name: player.fullname,
          bats: player.battingstyle,
          bowls: player.bowlingstyle,
          dob: player.dateofbirth,
          nationality: '',
          pid: player.id,
          credit_points: Math.floor(Math.random() * (10 - 7 + 1) + 7),
          designationid: role,
          created_date: new Date(),
          teamid: team._id,
          image: playersImage,
        };

        const newPlayer = new this.playerModel(playerData);
        await newPlayer.save();

        const matchPlayerData = {
          matchid: matchId,
          teamid: team._id,
          playerid: newPlayer._id,
          designationid: role,
          created_date: new Date(),
        };
        await this.MatchModel.updateOne({ _id: matchId }, { $push: { players: matchPlayerData } });
      } else {
        const matchPlayerData = {
          matchid: matchId,
          teamid: team._id,
          playerid: existingPlayer._id,
          designationid: role,
          created_date: new Date(),
        };
        await this.MatchModel.updateOne({ _id: matchId }, { $push: { players: matchPlayerData } });
      }
    }
  }


  //   Create PlayerScore

  async createPlayerScore(payload: any) {
    try {
      const { match_id, player_id, runs, wickets, catches, points } = payload.body;
      const createdPlayerScore = await this.PlayerScoreModel.create({
        match_id,
        player_id,
        runs,
        wickets,
        catches,
        points,
      });

      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        data: createdPlayerScore,
        message: "Player Score created successfully",
      });


    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }



}

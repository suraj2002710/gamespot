import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Tournaments, TournamentsSchema } from "src/schema/tournaments.schema";
import { Users, UsersSchema } from "src/schema/user.schema";
import { TournamentService } from "./tournaments.service";
import { TournamentsController } from "./tournaments.controller";
import { ContestType, ContestTypeSchema } from "src/schema/contest_type.schema";
import { Player, PlayerSchema } from "src/schema/player.schema";
import { Team, TeamSchema } from "src/schema/team.schema";
import { Match, MatchSchema } from "src/schema/matchs.schema";
import { UserTeam, UserTeamSchema } from "src/schema/userTeam.schema";
import { PlayerScore, PlayerScoreSchema } from "src/schema/playerScore.schema";



@Module({
    imports:[MongooseModule.forFeature([
        { name: Users.name, schema: UsersSchema },
        { name: Tournaments.name, schema: TournamentsSchema },
        { name: ContestType.name, schema: ContestTypeSchema },
        { name: Player.name, schema: PlayerSchema },
        { name: Team.name, schema: TeamSchema },
        { name: Match.name, schema: MatchSchema },
        { name: UserTeam.name, schema: UserTeamSchema },
        { name: PlayerScore.name, schema: PlayerScoreSchema },
    ])],
    providers:[TournamentService],
    controllers:[TournamentsController]
})
export class TournamentsModuel{}
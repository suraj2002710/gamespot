import { Body, Controller } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { MessagePattern } from '@nestjs/microservices';

@Controller()
export class AuthController{
    constructor(private readonly Authservice:AuthService){}

    @MessagePattern({ cmd:"user_sign_up"})
    async sign_up(@Body() body:any){
        return await this.Authservice.sign_up(body)
    }

    @MessagePattern({ cmd:"user_login"})
    async login(@Body() body:any){
        return await this.Authservice.login(body)
    }

    @MessagePattern({ cmd: 'user_update_profile' })
    async update_profile(@Body() body: any) {
        
        return await this.Authservice.update_profile(body);
    }

    @MessagePattern({ cmd: 'user_get_profile' })
    async get_profile(@Body() body: any) {
        return await this.Authservice.get_profile(body);
    }

    @MessagePattern({ cmd: 'forgot_password' })
    async forgot_password(@Body() body: any) {
        return await this.Authservice.forgot_password(body);
    }

    @MessagePattern({ cmd: 'forgot_password_otp_verify' })
    async verify_email_and_phone(@Body() body: any) {
        console.log("enter auth");
        return await this.Authservice.forgot_password_otp_verify(body);
    }

    @MessagePattern({ cmd: 'reset_password' })
    async reset_password(@Body() body: any) {
        return await this.Authservice.reset_password(body);
    }

    @MessagePattern({ cmd: 'remove_profile' })
    async remove_profile(@Body() body: any) {
        
        return await this.Authservice.remove_profile(body);
    }

    @MessagePattern({ cmd: "user_send_login_otp" })
    async send_login_otp(@Body() body: any) {
        return await this.Authservice.send_login_otp(body)
    }

    @MessagePattern({ cmd: "user_login_otp_verify" })
    async login_otp_verify(@Body() body: any) {
        return await this.Authservice.login_otp_verify(body)
    }

}
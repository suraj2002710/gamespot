import { Module } from "@nestjs/common";
import { AuthController } from "./auth.controller";
import { AuthService } from "./auth.service";
import { MongooseModule } from "@nestjs/mongoose";
import { Users, UsersSchema } from "src/shcema/user.schema";
import { UsersPhoneOtp, UsersPhoneOtpSchema } from "src/shcema/users_phone_otp.schema";
import { UsersEmailOtp, UsersEmailOtpSchema } from "src/shcema/user_email_otp.schema";
import { JwtModule } from "@nestjs/jwt";
import { CommonConfig } from "src/config/CommanConfig";
import { MailerModule } from "@nestjs-modules/mailer";
import { RefralEarning, RefralEarningSchema } from "src/shcema/referal_earning.schema";


@Module({
    imports:[
        MailerModule.forRoot({
            transport: {
                host: CommonConfig.EMAIL_HOST,
                port: 587,
                secure: false,
                auth: {
                    user: CommonConfig.EMAIL_AUTH_USER,
                    pass: CommonConfig.EMAIL_AUTH_PASS
                }
            },
            defaults: {
                from: CommonConfig.EMAIL_AUTH_USER,
            }
        }),
        MongooseModule.forFeature([
            { name: Users.name, schema: UsersSchema },
            { name: UsersPhoneOtp.name, schema:UsersPhoneOtpSchema },
            { name: UsersEmailOtp.name, schema: UsersEmailOtpSchema },
            { name: RefralEarning.name, schema: RefralEarningSchema },
        ]),
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
    ],
    controllers:[AuthController],
    providers:[AuthService]
})
export class AuthModule{

}

import { Inject, Injectable } from "@nestjs/common";
import { InjectModel } from '@nestjs/mongoose';
import * as bcrypt from 'bcrypt';

import { Model } from "mongoose";
import { CommonConfig } from "src/config/CommanConfig";
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";
import { Users } from "src/shcema/user.schema";
import { UsersEmailOtp } from "src/shcema/user_email_otp.schema";
import { UsersPhoneOtp } from "src/shcema/users_phone_otp.schema";
import { JwtService } from "@nestjs/jwt";

import { RefralcodeGen, generateOTP, generateOTPPhone, generateRandomUsername, sendEmail } from "src/utils/Helper";
import { CatchErrorResponseHelper, QueryErrorResponseHelper, ResponseHelper } from "src/utils/Response";
import { MailerService } from "@nestjs-modules/mailer";

@Injectable()
export class AuthService {
    constructor(@InjectModel(Users.name) private readonly UsersModel: Model<Users>,
        @InjectModel(UsersPhoneOtp.name)
        private readonly UsersPhoneOtpModel: Model<UsersPhoneOtp>,
        private jwtService: JwtService,
        @InjectModel(UsersEmailOtp.name)
        private readonly UsersEmailOtpModel: Model<UsersEmailOtp>,
        private readonly mailerService: MailerService,
    ) { }

    async sign_up(payload: any): Promise<any> {
        try {
            const {
                name,
                email,
                password,
                reg_type,
                api_type,
                country,
                currency,
                phone_number,
                country_code,
                promo_code,
                otp,
                confirm_otp_status,
            } = payload?.body;
            const user_ip = payload?.headers?.user_ip ? payload?.headers?.user_ip : '1.39.255.255';
            console.log("payload===>>>>>>>>>>", payload)
            var code = await RefralcodeGen();
            //register by phone=========================================== 
            if (reg_type == 'phone') {
                /* ==== Check phone exits start ===== */
                if (phone_number) {
                    const phone_number_exits: any = await this.UsersModel.findOne({
                        phone_number,
                        country_code,
                    });
                    if (phone_number_exits) {
                        return await ResponseHelper({
                            status: Status?.STATUS_FALSE,
                            status_code: StatusCode?.HTTP_OK,
                            message: `Phone Number ${MessageConstant?.IS_ALREADY_EXITS}`
                        });
                    }
                }
                /* ==== Check phone exits end ===== */
                if (api_type == 'phone_otp') {
                    console.log("phone_otp")
                    const otp = await generateOTPPhone(phone_number);;

                    return await this.UsersPhoneOtpModel.findOneAndUpdate(
                        { country_code, phone_number },
                        { otp },
                        { upsert: true, new: true },
                    )
                        .then(async (upserOtpData) => {
                            let message = `OTP sent ${MessageConstant?.SUCCESSFULLY} Please confirm now.`;
                            console.log("upserOtpData", upserOtpData, await ResponseHelper({
                                status: Status?.STATUS_TRUE,
                                status_code: StatusCode?.HTTP_OK,
                                message: message,
                            }))
                            return await ResponseHelper({
                                status_code: StatusCode?.HTTP_OK,
                                message: message,
                            });
                        })
                        .catch(async (error) => {
                            console.log('error>>>>>', error);
                            await QueryErrorResponseHelper(error, {
                                custom_code: StatusCode?.HTTP_BAD_REQUEST,
                                custom_message: `User ${MessageConstant?.IS_NOT_CORRECT}`,
                            });
                        });
                }
                if (api_type == 'confirm_phone_otp') {
                    return await this.UsersPhoneOtpModel.findOne({
                        country_code,
                        phone_number,
                        otp,
                    }).then(async (phoneOtp) => {
                        console.log("phoneOtp", phoneOtp, otp)

                        if (phoneOtp) {

                            return await ResponseHelper({
                                status: Status?.STATUS_TRUE,
                                status_code: StatusCode?.HTTP_OK,
                                message: `OTP verified ${MessageConstant?.SUCCESSFULLY}`,
                            });
                        } else {
                            // return await QueryErrorResponseHelper(
                            //     {
                            //         code: StatusCode?.HTTP_VALIDATION_ERROR,
                            //         message: MessageConstant?.OTP_MISMATCH,
                            //     },
                            //     {
                            //         custom_code: StatusCode?.HTTP_VALIDATION_ERROR,
                            //         custom_message: MessageConstant?.OTP_MISMATCH,
                            //     },
                            // );
                            return await ResponseHelper({
                                status: Status?.STATUS_FALSE,
                                status_code: StatusCode?.HTTP_OK,
                                message: MessageConstant?.OTP_MISMATCH,
                            });
                        }
                    });
                }
                if (confirm_otp_status != 1) {
                    // return await QueryErrorResponseHelper(
                    //     {
                    //         code: StatusCode?.HTTP_VALIDATION_ERROR,
                    //         message: 'Please confirm otp first.',
                    //     },
                    //     {
                    //         custom_code: StatusCode?.HTTP_VALIDATION_ERROR,
                    //         message: 'Please confirm otp first.',
                    //     },
                    // );
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_OK,
                        message: 'Please confirm otp first.',
                    });
                }
                const hash = await bcrypt.hash(password, CommonConfig.BCRYPTSALT);
                console.log("hash", hash);
                // $2b$10$.3bAkyrr1zraBIePmWeEcu00pJ2PJZvy / GXX9haol6azSvDkRiD36
                // $2b$10$.3bAkyrr1zraBIePmWeEcu00pJ2PJZvy / GXX9haol6azSvDkRiD36
                const create = {
                    username: await generateRandomUsername(),
                    email,
                    password: hash,
                    status: 1,
                    country,
                    currency,
                    phone_number,
                    country_code,
                    promo_code,
                    referral_code: code,
                };
                let self = this
                return await this.UsersModel.create(create)
                    .then(async (update) => {
                        if (update) {
                            const user = await this.UsersModel.findOne(
                                { phone_number, country_code },
                                CommonConfig.USER_ATRIBS,
                            );



                            var message = `Sign up ${MessageConstant?.SUCCESSFULLY}. You can login now.`;
                            return await ResponseHelper({
                                status: Status?.STATUS_TRUE,
                                status_code: StatusCode?.HTTP_OK,
                                message: message,
                                data: user,
                            });
                        }
                        /* ==== Create user end ===== */
                    })
                    .catch(async (error) => {
                        console.log('error>>>>>', error);
                        await QueryErrorResponseHelper(error, {
                            custom_code: StatusCode?.HTTP_BAD_REQUEST,
                            custom_message: `User ${MessageConstant?.IS_NOT_CORRECT}`,
                        });
                    });
            }
            //register by email===========================================
           else if (reg_type == 'email') {
                /* ==== Check e-mail exits start ===== */
                const email_exits: any = await this.UsersModel.findOne({
                    email: email,
                });
                if (email_exits) {
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `E-mail id ${MessageConstant?.IS_ALREADY_EXITS}`,
                      
                    });
                    
                    // await QueryErrorResponseHelper(
                    //     {
                    //         code: StatusCode?.HTTP_VALIDATION_ERROR,
                    //         message: `E-mail id ${MessageConstant?.IS_ALREADY_EXITS}`,
                    //     },
                    //     {
                    //         custom_code: StatusCode?.HTTP_VALIDATION_ERROR,
                    //         custom_message: `E-mail id ${MessageConstant?.IS_ALREADY_EXITS}`,
                    //     },
                    // );
                }
                /* ==== Check e-mail exits end ===== */
                /* ==== Check phone exits start ===== */
                if (phone_number) {
                    const phone_number_exits: any = await this.UsersModel.findOne({
                        phone_number,
                        country_code,
                    });
                    if (phone_number_exits) {
                        return await ResponseHelper({
                            status: Status?.STATUS_FALSE,
                            status_code: StatusCode?.HTTP_OK,
                            message: `Phone Number ${MessageConstant?.IS_ALREADY_EXITS}`,
                          
                        });
                    }
                }
                /* ==== Check phone exits end ===== */

                if (api_type == 'email_otp') {
                    console.log("email_otp")
                    const otp = await generateOTP();
                    return await this.UsersEmailOtpModel.findOneAndUpdate(
                        { email },
                        { otp },
                        { upsert: true, new: true },
                    )
                        .then(async (upserOtpData) => {
                            console.log(upserOtpData)
                            let message = `OTP sent ${MessageConstant?.SUCCESSFULLY} Please confirm now.`;
                            return await ResponseHelper({
                                status: Status?.STATUS_TRUE,
                                status_code: StatusCode?.HTTP_OK,
                                message: message,
                            });
                        })
                        .catch(async (error) => {
                            console.log('error>>>>>', error);
                            await QueryErrorResponseHelper(error, {
                                custom_code: StatusCode?.HTTP_BAD_REQUEST,
                                custom_message: `User ${MessageConstant?.IS_NOT_CORRECT}`,
                            });
                        });
                }
                if (api_type == 'confirm_email_otp') {
                    return await this.UsersEmailOtpModel.findOne({ email, otp }).then(
                        async (phoneOtp) => {
                            if (phoneOtp) {
                                return await ResponseHelper({
                                    status: Status?.STATUS_TRUE,
                                    status_code: StatusCode?.HTTP_OK,
                                    message: `OTP verified ${MessageConstant?.SUCCESSFULLY}. You can register now.`,
                                });
                            } else {
                                return await ResponseHelper({
                                    status: Status?.STATUS_FALSE,
                                    status_code: StatusCode?.HTTP_OK,
                                    message: MessageConstant?.OTP_MISMATCH,
                                });
                            }
                        },
                    );
                }
                if (confirm_otp_status != 1) {
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_OK,
                        message: 'Please confirm otp first.',
                    });
                }

                /* ==== Create user start ===== */
                const hash = await bcrypt.hash(password, CommonConfig.BCRYPTSALT);
                const create = {
                    name,
                    username: await generateRandomUsername(),
                    email,

                    password: hash,
                    status: 1,
                    country,
                    currency,
                    phone_number,
                    country_code,
                    promo_code,
                    referral_code: code,
                };
                return await this.UsersModel.create(create)
                    .then(async (update) => {
                        if (update) {
                            const user = await this.UsersModel.findOne(
                                { email },
                                CommonConfig.USER_ATRIBS,
                            );

                            var message = `Sign up ${MessageConstant?.SUCCESSFULLY}. You can login now.`;
                            return await ResponseHelper({
                                status: Status?.STATUS_TRUE,
                                status_code: StatusCode?.HTTP_OK,
                                message: message,
                                data: user,
                            });
                        }
                        /* ==== Create user end ===== */
                    })
                    .catch(async (error) => {
                        console.log('error>>>>>', error);
                        await QueryErrorResponseHelper(error, {
                            custom_code: StatusCode?.HTTP_BAD_REQUEST,
                            custom_message: `User ${MessageConstant?.IS_NOT_CORRECT}`,
                        });
                    });
            }
            
        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }

    async login(payload: any) {
        try {
            const { login_type, phone_number, email, password } = payload.body
            console.log("payload=====>", payload);

            if (login_type == "phone") {
                const find_user = await this.UsersModel.findOne({ phone_number })
                if (find_user) {
                    const compare_password = await bcrypt.compare(password, find_user.password)
                    console.log(typeof find_user.password, typeof password, compare_password , 'kk');

                    if (compare_password) {
                        const token = await this.jwtService.sign({ email: find_user?.email, id: find_user?._id })
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: MessageConstant.LOGIN_SUCCESS,
                            data: find_user,
                            access_token: token
                        });
                    } else {
                        return await ResponseHelper({
                            status: Status?.STATUS_FALSE,
                            status_code: StatusCode?.HTTP_BAD_REQUEST,
                            message: "Wrong Password",


                        });
                    }
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "User Not Found"
                });
            }
            if (login_type == "email") {
                const find_user = await this.UsersModel.findOne({ email })
                if (find_user) {
                    const compare_password = await bcrypt.compare(password, find_user.password)
                    if (compare_password) {
                        const token = await this.jwtService.sign({ email: find_user?.email, id: find_user?._id })
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: MessageConstant.LOGIN_SUCCESS,
                            data: find_user,
                            access_token: token
                        });
                    }
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: "Wrong Password",
                    });
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "User Not Found"
                });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }


    async update_profile(payload: any): Promise<any> {
        try {
            const { name, phone_country_code, zip_code, address, city, country, email, token, phone_number } =
                payload?.body;
                console.log(payload);
                
            const loginUser = payload?.loginUser;
            let updateData: any = {
                name,
                phone_country_code: phone_country_code ? phone_country_code : null,
                phone_number,
                zip_code
                , address
                , city, country
            };
            /* ==== Check e-mail exits start ===== */
            if (email) {
                updateData.email = email
                const email_exits: any = await this.UsersModel.findOne({
                    email: email,
                    _id: { $ne: loginUser?.id },
                });
                if (email_exits) {
                    await QueryErrorResponseHelper(
                        {
                            code: StatusCode?.HTTP_VALIDATION_ERROR,
                            message: `E-mail id ${MessageConstant?.IS_ALREADY_EXITS}`,
                        },
                        {
                            custom_code: StatusCode?.HTTP_VALIDATION_ERROR,
                            custom_message: `E-mail id ${MessageConstant?.IS_ALREADY_EXITS}`,
                        },
                    );
                }
            }
            /* ==== Check e-mail exits end ===== */
            /* ==== File upload start ===== */
            let profile_pic;
            if (payload?.file) {
                // const fileProfile = payload?.file;
                // const uploadedFile = await this.fileManagerClientProxy
                //     .send(
                //         { cmd: 'file_manager_upload_file' },
                //         {
                //             file: fileProfile,
                //             folder: CommonConfig?.AWS_BUCKET_UPLOAD_PATH_ADMIN,
                //         },
                //     )
                //     .toPromise();
                // if (uploadedFile?.key) {
                //     profile_pic = uploadedFile?.key;
                // }
            }
            /* ==== File upload end ===== */
            /* ==== Update user start ===== */
            updateData.profile_pic = profile_pic
            return await this.UsersModel.findByIdAndUpdate(
                { _id: loginUser?.id },
                updateData,
            )
                .then(async (update) => {
                    if (update) {
                        const user = await this.UsersModel.findOne(
                            { _id: loginUser?.id }
                        );
                        var message = `Profile ${MessageConstant?.UPDATED_SUCCESS}`;
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: message,
                            data: user,
                        });
                    }
                    /* ==== Update user end ===== */
                })
                .catch(async (error) => {
                    await QueryErrorResponseHelper(error, {
                        custom_code: StatusCode?.HTTP_BAD_REQUEST,
                        custom_message: `User ${MessageConstant?.IS_NOT_CORRECT}`,
                    });
                });
        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }


    async get_profile(payload: any) {
        try {
            const loginUser = payload?.loginUser;
            console.log(loginUser);
            
            const userDoc: any = await this.UsersModel.findOne({
                _id: loginUser?.id,
            }).exec();
            // const bonus = await this.BonusModel.find({ user_id: loginUser?.id }).exec()
            // const user = userDoc.toObject();
            // user.bonuses = bonus;
            return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                message: `Profile ${MessageConstant?.GET_SUCCESS}`,
                data: userDoc,
            });
        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }

    async forgot_password(payload: any) {
        try {
            const { is_type, country_code, email, phone } = payload?.body;
            let isEmailFormat = this.isEmail(email);
            // const user: any = await this.UsersModel.findOne({
            //   email: email,
            // });
            let user: any
            if (is_type === "phone") {
                user = await this.UsersModel.findOne(
                    {
                        phone_number: phone,
                        country_code
                    },
                );
            }
            if (is_type === "email") {
                user = await this.UsersModel.findOne(
                    {
                        email: email,
                    },
                );
            }
            if (user) {
                if(is_type === "email"){
                /* ==== Forgot password e-mail send start ===== */
                if (isEmailFormat) {
                    let otp = await generateOTP();
                    let payloadOtp = { body: { otp: otp, name: user?.name, email } };

                    // this.communicationClientProxy.emit('otp_send_mail', payloadOtp);
                    await this.UsersModel.findByIdAndUpdate(
                        { _id: user?._id },
                        { otp: otp },
                    );
                    /* ==== Forgot password e-mail send end ===== */
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `OTP Sent ${MessageConstant?.SUCCESSFULLY}`,
                    });
                } else {
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: `E-mail id ${MessageConstant?.IS_NOT_MATCHED}`,
                    });
                }
            }
            else if(is_type === "phone"){
                let otp = await generateOTPPhone(phone);
                // let payloadOtp = { body: { otp: otp, name: user?.name, email } };
                // this.communicationClientProxy.emit('otp_send_mail', payloadOtp);
                await this.UsersModel.findByIdAndUpdate(
                    { _id: user?._id },
                    { otp: otp },
                );
                /* ==== Forgot password e-mail send end ===== */
                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: `OTP Sent ${MessageConstant?.SUCCESSFULLY}`,
                });
            }
            } else {
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `User ${MessageConstant?.IS_NOT_FOUND}`,

                });
            }
        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }

    async forgot_password_otp_verify(payload: any) {
        try {
            const loginUser = payload?.loginUser;
            const { user_id, email, phone_number, otp, country_code, req_type, confirm_otp_status, api_type } = payload.body
            // let user_id=loginUser?.id
            /* ==== Update profile start ===== */

            //register by phone===========================================
            if (req_type == 'phone') {

                const find_user = await this.UsersModel.findOne({
                    phone_number,country_code,otp
                })
                if(find_user){
                    await this.UsersModel.findByIdAndUpdate({ _id: find_user._id }, { $set: { phone_varified_at: new Date(Date.now()) } })

                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `OTP verified ${MessageConstant?.SUCCESSFULLY}`,
                    });
                }else{
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: `OTP Mismatch`,
                    });
                }

            }

            if (req_type == 'email') {
                /* ==== Check e-mail exits start ===== */
                const find_user = await this.UsersModel.findOne({
                    email, otp
                })
                if (find_user) {
                    await this.UsersModel.findByIdAndUpdate({ _id: find_user._id }, { $set: { phone_varified_at: new Date(Date.now()) } })

                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `OTP verified ${MessageConstant?.SUCCESSFULLY}`,
                    });
                } else {
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: `OTP Mismatch`,
                    });
                }

            }

        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }

    async reset_password(payload: any) {

        try {
            const { is_type, email, phone, otp, password, country_code } = payload?.body;
            console.log(payload);
            let user: any
            if (is_type === "email") {
                user = await this.UsersModel.findOne({ email: email, otp })
            }
            if (is_type === "phone") {
                user = await this.UsersModel.findOne({ phone_number: phone, otp, country_code })
            }
            /* ==== Match User Tokens start ===== */
         
            // const user = await this.UsersModel.findOne({ email: email, otp });
            if (user) {
                
                /* ==== Update password start ===== */
                const hash = await bcrypt.hash(password, CommonConfig.BCRYPTSALT);
                console.log(hash , 'jhjj')
                const update = await this.UsersModel.findByIdAndUpdate(
                    {
                        _id: user?._id,
                    },
                    {
                        password: hash,
                    },
                );
                /* ==== Update password end ===== */
                if (update) {
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: `Reset password ${MessageConstant?.SUCCESSFULLY}`,
                    });
                }
                /* ==== Match User Tokens start ===== */
            } else {
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `${MessageConstant?.OTP_MISMATCH}`,
                });
                // await QueryErrorResponseHelper(
                //     {
                //         code: StatusCode?.HTTP_VALIDATION_ERROR,
                //         message: `${MessageConstant?.OTP_MISMATCH}`,
                //     },
                //     {
                //         custom_code: StatusCode?.HTTP_VALIDATION_ERROR,
                //         custom_message: `${MessageConstant?.OTP_MISMATCH}`,
                //     },
                // );
            }
        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }

    async remove_profile(payload: any) {
        try {
            const loginUser = payload?.loginUser;
            /* ==== Update profile start ===== */
            const updateData = {
                profile_pic: null,
            };
            return await this.UsersModel.findByIdAndUpdate(
                { _id: loginUser?.id },
                updateData,).then(async (update) => {
                    if (update) {
                        const user = await this.UsersModel.findOne({ _id: loginUser?.id });
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: `Profile ${MessageConstant?.REMOVE_SUCCESSFULLY}`,
                            data: user,
                        });
                    }
                    /* ==== Update profile end ===== */
                })
                .catch(async (error) => {
                    await QueryErrorResponseHelper(error, {
                        custom_code: StatusCode?.HTTP_BAD_REQUEST,
                        custom_message: `User ${MessageConstant?.IS_NOT_CORRECT}`,
                    });
                });
        } catch (error: any) {
            await CatchErrorResponseHelper(error);
        }
    }

    async send_login_otp(payload: any) {
        try {
            const { login_type, phone, email, password } = payload.body
            console.log("otp send=====>", payload);

            if (login_type == "phone") {
                const find_user = await this.UsersModel.findOne({ phone })
                console.log(find_user, "find_user");

                if (find_user) {
                    const otp = await generateOTPPhone(phone)
                    await this.UsersModel.updateOne({ _id: find_user?._id }, { $set: { otp: otp } })
                    return await ResponseHelper({
                        status: Status?.STATUS_TRUE,
                        status_code: StatusCode?.HTTP_OK,
                        message: "Otp send Successfully"
                    });
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "User Not Found"
                });
            }
            if (login_type == "email") {
                const find_user = await this.UsersModel.findOne({ email })
                if (find_user) {
                    let otp = await generateOTP()
                    let subject = CommonConfig.LOGIN_OTP
                    let mail = await sendEmail(this.mailerService, otp, email, subject)
                    console.log(mail, "mail mail mail mail====>>>>>");

                    if (mail) {
                        await this.UsersModel.updateOne({ _id: find_user?._id }, { $set: { otp: otp } })
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: "Otp send Successfully"
                        });
                    }
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: "Mail Not Send Some Issue"
                    });
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: "User Not Found"
                });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }

    async login_otp_verify(payload: any) {
        try {
            const { login_type, phone, email, otp } = payload.body
            console.log("otp send=====>", payload);

            if (login_type == "phone") {
                const find_user = await this.UsersModel.findOne({ phone })
                console.log(find_user, "find_user");

                if (find_user) {
                    if (otp == find_user.otp) {

                        const token = await this.jwtService.sign({ email: find_user?.email, id: find_user?._id })
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: MessageConstant.LOGIN_SUCCESS,
                            data: find_user,
                            access_token: token
                        });
                    }
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: `OTP Mismatch`,
                    });
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `User Not Found`,
                });
            }
            if (login_type == "email") {
                const find_user = await this.UsersModel.findOne({ email })
                if (find_user) {
                    if (otp == find_user.otp) {

                        const token = await this.jwtService.sign({ email: find_user?.email, id: find_user?._id })
                        return await ResponseHelper({
                            status: Status?.STATUS_TRUE,
                            status_code: StatusCode?.HTTP_OK,
                            message: MessageConstant.LOGIN_SUCCESS,
                            data: find_user,
                            access_token: token
                        });
                    }
                    return await ResponseHelper({
                        status: Status?.STATUS_FALSE,
                        status_code: StatusCode?.HTTP_BAD_REQUEST,
                        message: `OTP Mismatch`,
                    });
                }
                return await ResponseHelper({
                    status: Status?.STATUS_FALSE,
                    status_code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `User Not Found`,
                });
            }
        } catch (error) {
            await CatchErrorResponseHelper(error)
        }
    }


    private isEmail(str: string): boolean {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(str);
    }
}
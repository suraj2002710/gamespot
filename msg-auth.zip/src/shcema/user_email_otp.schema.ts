import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
export type UsersEmailOtpDocument = HydratedDocument<UsersEmailOtp>;

@Schema({ timestamps: true, collection: 'users_email_otp' })
export class UsersEmailOtp {


    @Prop({ default: '' })
    email: string;

    @Prop({ default: '' })
    otp: string;

    @Prop({ default: null })
    email_verified_at: Date;
}

export const UsersEmailOtpSchema = SchemaFactory.createForClass(UsersEmailOtp);

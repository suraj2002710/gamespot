import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';

export type MainAdminDocument = HydratedDocument<Admin>;


@Schema({ timestamps: true })
export class Admin {

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Admin' })
    created_by: Admin;

    @Prop()
    name: string;

    @Prop({ required: true })
    email: string;

    @Prop()
    profile_pic: string;

    @Prop()
    password: string;

    @Prop()
    phone_country_code: string;

    @Prop()
    phone_number: string;

    @Prop()
    tg_id: string;

    @Prop()
    otp: string;

    @Prop()
    username: string;

    @Prop({ default: 0 })
    status: number; // 0=inactive,1=active 
}

export const AdminSchema = SchemaFactory.createForClass(Admin);
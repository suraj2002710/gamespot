import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
export type UsersPhoneOtpDocument = HydratedDocument<UsersPhoneOtp>;

@Schema({ timestamps: true, collection: 'users_phone_otp' })
export class UsersPhoneOtp {
    @Prop()
    country_code: number;

    @Prop({ default: '' })
    phone_number: number;

    @Prop({ default: '' })
    otp: string;

    @Prop({ default: null })
    phone_verified_at: Date;
}

export const UsersPhoneOtpSchema = SchemaFactory.createForClass(UsersPhoneOtp);

import { Module } from "@nestjs/common";
import { AuthController } from "./auth.controller";
import { AdminAuthService } from "./auth.service";
import { MongooseModule } from "@nestjs/mongoose";
import { Users, UsersSchema } from "src/shcema/user.schema";
import { UsersPhoneOtp, UsersPhoneOtpSchema } from "src/shcema/users_phone_otp.schema";
import { UsersEmailOtp, UsersEmailOtpSchema } from "src/shcema/user_email_otp.schema";
import { JwtModule } from "@nestjs/jwt";
import { CommonConfig } from "src/config/CommanConfig";
import { Admin, AdminSchema } from "src/shcema/admin.schema";
import { MailerModule } from "@nestjs-modules/mailer";


@Module({
    imports:[
        MailerModule.forRoot({
            transport: {
                host: CommonConfig.EMAIL_HOST,
                port: 587,
                secure: false,
                auth: {
                    user: CommonConfig.EMAIL_AUTH_USER,
                    pass: CommonConfig.EMAIL_AUTH_PASS
                }
            },
            defaults: {
                from: CommonConfig.EMAIL_AUTH_USER,
            }
        }),
        MongooseModule.forFeature([
            { name: Admin.name, schema: AdminSchema },
            { name: UsersPhoneOtp.name, schema:UsersPhoneOtpSchema },
            { name: UsersEmailOtp.name, schema: UsersEmailOtpSchema },
        ]),
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
    ],
    controllers:[AuthController],
    providers:[AdminAuthService]
})
export class AdminAuthModule{

}

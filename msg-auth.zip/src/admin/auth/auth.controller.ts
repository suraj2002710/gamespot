import { Body, Controller } from "@nestjs/common";
import { AdminAuthService } from "./auth.service";
import { MessagePattern } from '@nestjs/microservices';

@Controller()
export class AuthController{
    constructor(private readonly AdminAuthService:AdminAuthService){}


    @MessagePattern({ cmd:"admin_login"})
    async login(@Body() body:any){
        return await this.AdminAuthService.login(body)
    }

    @MessagePattern({ cmd:"send_login_otp"})
    async send_login_otp(@Body() body:any){
        return await this.AdminAuthService.send_login_otp(body)
    }

    @MessagePattern({ cmd:"login_otp_verify"})
    async login_otp_verify(@Body() body:any){
        return await this.AdminAuthService.login_otp_verify(body)
    }
}
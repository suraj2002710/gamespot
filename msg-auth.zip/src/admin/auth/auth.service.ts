import { Inject, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import * as bcrypt from 'bcrypt';

import { Model } from 'mongoose';
import { CommonConfig } from 'src/config/CommanConfig';
import { Status, StatusCode } from 'src/constants/HttpConstant';
import { MessageConstant } from 'src/constants/MessageConstant';
import { Users } from 'src/shcema/user.schema';
import { UsersEmailOtp } from 'src/shcema/user_email_otp.schema';
import { UsersPhoneOtp } from 'src/shcema/users_phone_otp.schema';
import { JwtService } from '@nestjs/jwt';

import {
  RefralcodeGen,
  generateOTP,
  generateOTPPhone,
  generateRandomUsername,
  sendEmail,
} from 'src/utils/Helper';
import {
  CatchErrorResponseHelper,
  QueryErrorResponseHelper,
  ResponseHelper,
} from 'src/utils/Response';
import { Admin } from 'src/shcema/admin.schema';
import { MailerService } from '@nestjs-modules/mailer';

@Injectable()
export class AdminAuthService {
  constructor(
    @InjectModel(Admin.name) private readonly AdminModel: Model<Admin>,
    private readonly mailerService: MailerService,
    private jwtService: JwtService,
  ) {}
  async login(payload: any) {
    try {
      const { login_type, phone, email, password } = payload.body;
      console.log('payload=====>', payload);

      if (login_type == 'phone') {
        const find_user = await this.AdminModel.findOne({
          phone_number: phone,
        });
        console.log(find_user, 'find_user');

        if (find_user) {
          const compare_password = await bcrypt.compare(
            password,
            find_user.password,
          );
          console.log(
            typeof find_user.password,
            typeof password,
            compare_password,
          );

          if (compare_password) {
            const token = await this.jwtService.sign({
              email: find_user?.email,
              id: find_user?._id,
            });
            return await ResponseHelper({
              status: Status?.STATUS_TRUE,
              status_code: StatusCode?.HTTP_OK,
              message: MessageConstant.LOGIN_SUCCESS,
              data: find_user,
              access_token: token,
            });
          } else {
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'Wrong Password',
            });
          }
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: 'User Not Found',
          });
        }
      }
      if (login_type == 'email') {
        let isEmailFormat = this.isEmail(email);
        if (isEmailFormat) {
          const find_user = await this.AdminModel.findOne({ email });

          if (find_user) {
            const compare_password = await bcrypt.compare(
              password,
              find_user.password,
            );
            if (compare_password) {
              const token = await this.jwtService.sign({
                email: find_user?.email,
                id: find_user?._id,
              });
              return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                message: MessageConstant.LOGIN_SUCCESS,
                data: find_user,
                access_token: token,
              });
            } else {
              return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                message: 'Wrong Password',
              });
            }
          } else {
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'User Not Found',
            });
          }
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: `E-mail id ${MessageConstant?.IS_NOT_MATCHED}`,
          });
        }
      }

      if (login_type != 'email' && login_type != 'phone') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Invalid Login Type',
        });
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async send_login_otp(payload: any) {
    try {
      const { login_type, phone, email, password } = payload.body;
      console.log('otp send=====>', payload);

      if (login_type == 'phone') {
        const find_user = await this.AdminModel.findOne({
          phone_number: phone,
        });
        console.log(find_user, 'find_user');

        if (find_user) {
          const otp = await generateOTPPhone(phone);
          await this.AdminModel.updateOne(
            { _id: find_user?._id },
            { $set: { otp: otp } },
          );
          return await ResponseHelper({
            status: Status?.STATUS_TRUE,
            status_code: StatusCode?.HTTP_OK,
            message: 'Otp send Successfully',
          });
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: 'User Not Found',
          });
        }
      }
      if (login_type == 'email') {
        let isEmailFormat = this.isEmail(email);
        if (isEmailFormat) {
          const find_user = await this.AdminModel.findOne({ email });
          console.log(find_user, 'find_user1');
          if (find_user) {
            let otp = await generateOTP();
            let subject = CommonConfig.LOGIN_OTP;
            let mail = await sendEmail(this.mailerService, otp, email, subject);
            console.log(mail, 'mail mail mail mail====>>>>>');

            if (mail) {
              await this.AdminModel.updateOne(
                { _id: find_user?._id },
                { $set: { otp: otp } },
              );
              return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                message: 'Otp send Successfully',
              });
            }
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'Mail Not Send Some Issue',
            });
          } else {
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'User Not Found',
            });
          }
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: `E-mail id ${MessageConstant?.IS_NOT_MATCHED}`,
          });
        }
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async login_otp_verify(payload: any) {
    try {
      const { login_type, phone, email, otp } = payload.body;
      console.log('otp send=====>', payload);

      if (login_type == 'phone') {
        const find_user = await this.AdminModel.findOne({ phone });
        console.log(find_user, 'find_user');

        if (find_user) {
          if (otp == find_user.otp) {
            const token = await this.jwtService.sign({
              email: find_user?.email,
              id: find_user?._id,
            });
            return await ResponseHelper({
              status: Status?.STATUS_TRUE,
              status_code: StatusCode?.HTTP_OK,
              message: MessageConstant.LOGIN_SUCCESS,
              data: find_user,
              access_token: token,
            });
          }
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: `OTP Mismatch`,
          });
        }
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: `User Not Found`,
        });
      }
      if (login_type == 'email') {
        let isEmailFormat = this.isEmail(email);
        if (isEmailFormat) {
          const find_user = await this.AdminModel.findOne({ email });
          if (find_user) {
            if (otp == find_user.otp) {
              const token = await this.jwtService.sign({
                email: find_user?.email,
                id: find_user?._id,
              });
              return await ResponseHelper({
                status: Status?.STATUS_TRUE,
                status_code: StatusCode?.HTTP_OK,
                message: MessageConstant.LOGIN_SUCCESS,
                data: find_user,
                access_token: token,
              });
            }
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: `OTP Mismatch`,
            });
          } else {
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: `User Not Found`,
            });
          }
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: `E-mail id ${MessageConstant?.IS_NOT_MATCHED}`,
          });
        }
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  private isEmail(str: string): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(str);
  }
}

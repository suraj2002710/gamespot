import { RpcException } from '@nestjs/microservices';
import { StatusCode, StatusMessage } from '../constants/HttpConstant';

/* ==== Response get start ===== */
export const GetResponseHelper = async (response: any) => {
    let get_response = <any>{};
    get_response['status'] = response?.status;
    get_response['status_code'] = response?.status_code;
    get_response['message'] = response?.message;
    if (response?.data !== undefined) {
        get_response['data'] = response?.data;
    }
    if (response?.error !== undefined) {
        get_response['error'] = response?.error;
    }
    if (response?.errors !== undefined) {
        get_response['errors'] = response?.errors;
    }
    if (response?.access_token !== undefined) {
        get_response['access_token'] = response?.access_token;
    }
    if (response?.refresh_token !== undefined) {
        get_response['refresh_token'] = response?.refresh_token;
    }
    return get_response;
}
/* ==== Response get end ===== */

/* ==== Response start ===== */
export const ResponseHelper = async (response: any) => {
    
    let get_response = await GetResponseHelper(response);
    // console.log(response, get_response);
    // console.log(response?.response?.status(response?.status_code).json(get_response));
    // response?.response?.status(response?.status_code).json(get_response);
    return get_response
}
/* ==== Response end ===== */

/* ==== Response simple start ===== */
export const ResponseJsonHelper = async (response: any) => {
    return await GetResponseHelper(response);
}
/* ==== Response  simple end ===== */

/* ==== Query error response start ===== */
export const QueryErrorResponseHelper = async (error: any, custom_error: any,) => {
    throw new RpcException({
        // custom_code: custom_error?.custom_code,
        // custom_message: custom_error?.custom_message

        custom_code: custom_error?.custom_code,
        message: error?.message
    });
}
/* ==== Query error response end ===== */

/* ==== Catch error response start ===== */
export const CatchErrorResponseHelper = async (error: any) => {
    throw new RpcException({
        // custom_code: error?.error?.custom_code || StatusCode?.HTTP_INTERNAL_SERVER_ERROR,
        // custom_message: error?.error?.custom_message || StatusMessage?.HTTP_INTERNAL_SERVER_ERROR

        custom_code: error?.error?.custom_code || StatusCode?.HTTP_INTERNAL_SERVER_ERROR,
        message: error?.message
    });
}
/* ==== Catch error response end ===== */
import { CommonConfig } from "src/config/CommanConfig";

// export const PayloadHelper = async (request: any) => {
//     const request_url = `${request?.protocol}://${request?.header('host')}${request?.originalUrl}`;
//     const request_method = request?.method;
//     const remote_ip = request?.ip;
//     const request_on = request?.originalUrl.replace(`/${CommonConfig.API_URL}`, "");
//     const request_url_array = request_on.split('/');
//     let action_from = 'api';
//     if (request_url_array?.length > 1) {
//         if (request_url_array[0] === 'admin') {
//             action_from = 'admin';
//         }
//     }
//     //testing push

//     let get_request = <any>{};
//     if (request?.headers !== undefined) {

//         get_request['headers'] = {
//             authorization: request?.headers?.authorization,
//             platform: request?.headers?.platform ? request?.headers?.platform : '',
//             api_version: request?.headers?.api_version ? Number(request?.headers?.api_version) : Number(1),
//             app_version: request?.headers?.app_version,
//             action_from: action_from,
//             request_url: request_url,
//             request_method: request_method,
//             request_on: request_on,
//             user_ip: request?.headers['x-real-ip'] ? request?.headers['x-real-ip'] : "1.39.255.255"
//             // user_ip: "1.39.255.255"
//         };
//     }
//     if (request?.user !== undefined) {
//         get_request['loginUser'] = request?.user;
//     }
//     if (request?.body !== undefined) {
//         get_request['body'] = request?.body;
//     }
//     if (request?.query !== undefined) {
//         get_request['query'] = request?.query;
//     }
//     if (request?.params !== undefined) {
//         get_request['params'] = request?.params;
//     }
//     if (request?.file !== undefined) {
//         get_request['file'] = request?.file;
//     }
//     if (request?.files !== undefined) {
//         get_request['files'] = request?.files;
//     }



//     return get_request;
// }
import { ConfigModule } from "@nestjs/config";
import 'dotenv/config';
ConfigModule.forRoot({
    isGlobal: true,
    envFilePath: [`${process.env.ENV_PATH}`],
});

export const CommonConfig = {

    USER_DATABASE_HOST: process.env.USER_DATABASE_HOST || 'localhost',
    USER_DATABASE_PORT: process.env.USER_DATABASE_PORT || 3306,
    USER_DATABASE_USER: process.env.USER_DATABASE_USER || 'root',
    USER_DATABASE_PWD: process.env.USER_DATABASE_PWD || 'root',
    USER_DATABASE_NAME: process.env.USER_DATABASE_NAME || '',

    PORT_AUTH: process.env.PORT_AUTH || "",
    PORT_COMMUNICATION: process.env.PORT_COMMUNICATION || '',
    PORT_APP: process.env.PORT_APP || '',
    PORT_FILE_MANAGER: process.env.PORT_FILE_MANAGER || '',
    PORT_CRON_JOB: process.env.PORT_CRON_JOB || '',
    PORT_PAYMENT: process.env.PORT_PAYMENT || '',
    PORT_LOGGER: process.env.PORT_LOGGER || '',
    PORT_USER: process.env.PORT_USER || '',


    HOST_AUTH: process.env.HOST_AUTH || '',
    HOST_COMMUNICATION: process.env.HOST_COMMUNICATION || '',
    HOST_APP: process.env.HOST_APP || '',
    HOST_FILE_MANAGER: process.env.HOST_FILE_MANAGER || '',
    HOST_CRON_JOB: process.env.HOST_CRON_JOB || '',
    HOST_PAYMENT: process.env.HOST_PAYMENT || '',
    HOST_LOGGER: process.env.HOST_LOGGER || '',
    HOST_USER: process.env.HOST_USER || '',


    API_ACCESS_TOKEN_SECRET: process.env.API_ACCESS_TOKEN_SECRET || 'MdUy5tx3DZjjxN6NkXA8duqhX8VcC4eGMqQCHyeqU9q5pDGzNLjwt',
    API_ACCESS_TOKEN_EXPIRATION: process.env.API_ACCESS_TOKEN_EXPIRATION || '1d',
    API_ACCESS_TOKEN_SIGNOPTIONS: { expiresIn: process.env.API_ACCESS_TOKEN_EXPIRATION || '1d' },
    API_REFRESH_TOKEN_SECRET: process.env.API_REFRESH_TOKEN_SECRET || 'SkiZHe4m4xSRbBrbyWzQaR2Y5pYZ746UGgSRkgFNRddDX6Nm5Ujwt',
    API_REFRESH_TOKEN_EXPIRATION: process.env.API_REFRESH_TOKEN_EXPIRATION || '1d',
    API_REFRESH_TOKEN_SIGNOPTIONS: { expiresIn: process.env.API_REFRESH_TOKEN_EXPIRATION || '1d' },





    MONGODB_URL: process.env.MONGODB_URL || '',

    MICROSERVICE_LIST: {
        AUTH: 'Auth microservice',
    },

    DEFAULT_TIMEZONE: 'UTC',
    DATE_TIME_FORMATE: 'YYYY-MM-DD[T]HH:mm:ss',

    BCRYPTSALT: 10,

    REDIS_HOST: process.env.REDIS_HOST || '127.0.0.1',
    REDIS_PORT: process.env.REDIS_PORT || 6379,
    REDIS_PASSWORD: process.env.REDIS_PASSWORD || 'redis@123',
    REDIS_TTL: Number(process.env.REDIS_TTL) || Number(60 * 60 * 24 * 7),

    AWS_BUCKET_PATH: process.env.AWS_BUCKET_PATH || '',
    AWS_BUCKET_UPLOAD_PATH_ADMIN: 'admin',

    PAGE: 0,
    PAGE_SIZE: 10,
    ORDER_DIRECTION: 'DESC',
    PAGINATION_PAGE_MIN: 0,
    PAGINATION_PAGE_SIZE_MIN: 1,
    PAGINATION_ORDER_DIRECTION: ['ASC', 'DESC'],

    PASSWORD_MATCHES: /^(?=.*[0-9])(?=.*[!@#?$%^&*-])(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9!@#?$%^&*-]{8,15}$/,
    PASSWORD_MIN: 8,
    PASSWORD_MAX: 15,

    EXPIRY_TIME: 15,
    EMAIL_RESTRICTION_TIME: 5,

    USERS_TYPES: [1, 2, 3],
    USERS_TYPES_LIST: {
        USER: 1,
        AUTHOR: 2,
        NARRATOR: 3,
    },

    ADMIN_ATRIBS: { _id: 1, name: 1, email: 1, phone_country_code: 1, phone_number: 1, tg_id: 1, status: 1, Wallet_balance: 1 },
    USER_ATRIBS: { _id: 1, name: 1, email: 1, phone_country_code: 1, phone_number: 1, tg_id: 1, status: 1, Wallet_balance: 1, username: 1 },

    IS_MAIL_WORKING: process.env.IS_MAIL_WORKING || '',
    IS_PHONE_WORKING: process.env.IS_PHONE_WORKING || '',
    UUID_RANDOM_NUMBER: process.env.UUID_RANDOM_NUMBER || 100000,



    GAME_PhoneVerify: 'User/PhoneVerify',

    LOGIN_OTP: process.env.LOGIN_OTP || "Login Otp",

    // Email otp
    EMAIL_AUTH_USER: process.env.EMAIL_AUTH_USER || "surajaheer448@gmail.com",
    EMAIL_AUTH_PASS: process.env.EMAIL_AUTH_PASS || "mamokewfitjsnxwt",
    EMAIL_HOST: process.env.EMAIL_HOST || "smtp.gmail.com",
}
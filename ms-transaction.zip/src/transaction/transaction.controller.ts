import { Body, Controller } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { TransactionService } from './transaction.service';

@Controller()
export class TransactionController {
    constructor(private readonly transactionService: TransactionService) { }

    @MessagePattern({ cmd: 'users_transaction_withdraw_request' })
    userTrasactionWithdrawReq(@Body() payload: any) {
        return this.transactionService.userTrasactionWithdrawReq(payload)
    }

    @MessagePattern({ cmd: 'withdraw_request_approval' })
    withdrawRequestApproval(@Body() payload: any) {
        return this.transactionService.withdrawReqApproval(payload)
    }

    @MessagePattern({ cmd: 'user_withdraw_verify' })
    userWithdrawVerify(@Body() payload: any) {
        return this.transactionService.userWithdrawVerify(payload)
    }

    @MessagePattern({ cmd: 'users_transaction_deposite_request' })
    userTrasactionDepositReq(@Body() payload: any) {
        return this.transactionService.userTrasactionDepositReq(payload)
    }

    @MessagePattern({ cmd: 'users_transaction_history' })
    userTrasactionHistory(@Body() payload: any) {
        return this.transactionService.userTransactionHistory(payload)
    }


}

import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as moment from 'moment';
import { Status, StatusCode } from 'src/constants/HttpConstant';
import { MessageConstant } from 'src/constants/MessageConstant';
import { getUniqueID, generateOTPPhone } from 'src/utils/Helper';
import {
  CatchErrorResponseHelper,
  QueryErrorResponseHelper,
  ResponseHelper,
} from 'src/utils/Response';
const jsSHA = require('jssha');
import { Transaction } from 'src/schema/transaction.schema';
import { Withdraw } from 'src/schema/withdraw.schema';
import { Users } from 'src/schema/users.schema';
import { BanckDetails } from 'src/schema/bank_details.schema';
// import { MainAdmin } from 'src/schema/main_admin.schema';
const axios = require('axios');

interface RequestData {
  merchantId: string;
  merchantTransactionId: string;
  merchantUserId: string;
  amount: number;
  redirectUrl: string;
  redirectMode: string;
  callbackUrl: string;
  paymentInstrument: { type: string };
}

@Injectable()
export class TransactionService {
  constructor(
    @InjectModel(Users.name) private readonly UserModel: Model<Users>,
    @InjectModel(Transaction.name)
    private readonly TransactionModel: Model<Transaction>,
    @InjectModel(Withdraw.name)
    private readonly WithdrawModel: Model<Withdraw>,
    @InjectModel(BanckDetails.name)
    private readonly BanckDetailsModel: Model<BanckDetails>,
  ) { }

  async userTrasactionDepositReq(payload: any) {
    try {
      const { amount, depositType } = payload.body;
      let userId = payload?.loginUser?.id;
      const txn = await this.TransactionModel.create({
        amount: amount,
        req_type: 'deposit',
        user_id: userId,
        client_ip: '',
        client_forwarded_ip: '',
        txn_msg: 'Payment not complete',
        status: 2,
      });


      return await ResponseHelper({
        status: Status?.STATUS_TRUE,
        status_code: StatusCode?.HTTP_OK,
        message:"Deposite Request Send Successfully",
        data: txn,
      });
      // if (depositType === 'Phonepe') {
      //   const txnId = 'PP' + getUniqueID();

      //   let requestData: RequestData = {
      //     merchantId: 'KKADDAPGONLINE',
      //     merchantTransactionId: txnId,
      //     merchantUserId: 'MUID125',
      //     amount: amount * 100,
      //     redirectUrl: 'https://kkadda.com/pay-status?txnId=' + txnId,
      //     redirectMode: 'GET',
      //     callbackUrl:
      //       'https://service.kkadda.com/phonpay-request-callback-6482',
      //     paymentInstrument: { type: 'PAY_PAGE' },
      //   };
      //   const base64Data = Buffer.from(JSON.stringify(requestData)).toString(
      //     'base64',
      //   );
      //   console.error(amount, 'req.body');
      //   let shaGenerated = '';
      //   var sha256 = new jsSHA('SHA-256', 'TEXT');
      //   sha256.update(
      //     base64Data + '/pg/v1/pay0bd9ae24-7500-46f5-86f2-74229d7261c2',
      //   );
      //   var hash = sha256.getHash('HEX');

      //   const verifyToken = hash + '###1';

      //   let data = JSON.stringify({
      //     request: base64Data,
      //   });

      //   let config = {
      //     method: 'post',
      //     maxBodyLength: Infinity,
      //     url: 'https://api.phonepe.com/apis/hermes/pg/v1/pay',
      //     headers: {
      //       accept: 'application/json',
      //       'Content-Type': 'application/json',
      //       'X-VERIFY': verifyToken,
      //     },
      //     data: data,
      //   };

      //   axios
      //     .request(config)
      //     .then(async (response) => {
      //       const txn = await this.TransactionModel.create({
      //         amount: amount,
      //         req_type: 'deposit',
      //         user_id: userId,
      //         client_ip: '',
      //         client_forwarded_ip: '',
      //         status: 0,
      //         payment_gatway: 'phonepe',
      //         order_id: txnId,
      //       });
      //       await txn.save();
      //       return await ResponseHelper({
      //         status: Status?.STATUS_TRUE,
      //         status_code: StatusCode?.HTTP_OK,
      //         data: txn,
      //       });
      //     })
      //     .catch(async (error) => {
      //       console.log(error, 'phonepay error');
      //       txn.save();
      //       return await ResponseHelper({
      //         status: Status?.STATUS_FALSE,
      //         status_code: StatusCode?.HTTP_BAD_REQUEST,
      //         data: null,
      //       });
      //     });
      // } else if (depositType === 'MYPAY') {

      // }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async userTrasactionWithdrawReq(payload: any) {
    try {
      const {
        amount,
        account_id
      } = payload.body;
      let userId = payload?.loginUser?.id;
      const find_account_details = await this.BanckDetailsModel.findOne({ _id: account_id })
      if (!find_account_details) {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Not found your Account Details',
        });
      }

      const find_user = await this.UserModel.findById(userId);
      if (find_user?.verified != 'complete') {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'Please Verify Your KYC. Then Withdrawle.',
        });
      }
      if (amount >= 100) {
        if (find_user.withdraw_holdbalance == 0) {
          if (
            find_user.Wallet_balance >= amount &&
            find_user.withdrawAmount >= amount
          ) {
            const otp = await generateOTPPhone(find_user.phone_number);

            const txn = await this.TransactionModel.create({
              amount,
              upi_id: find_account_details.upi,
              req_type: 'withdrawal',
              payment_methode: find_account_details.type,
              account_holder: find_account_details.account_holder_name,
              user_id: find_account_details.User_Id,
              status: 0,
              // withdrawType,
              withdrawOtp: otp,
              account_no: find_account_details.accountNumber,
              ifsc_code: find_account_details.ifsc_code,
            });

            // const withdraw = await this.WithdrawModel.create({
            //   amount,
            //   req_type: 'withdrawal',
            //   payment_methode: paymentMethode,
            //   user_id: userId,
            //   status: 0,
            //   closing_balance: find_user.Wallet_balance,
            //   txn_id: txn._id,
            // });

            return await ResponseHelper({
              status: Status?.STATUS_TRUE,
              status_code: StatusCode?.HTTP_OK,
              data: txn,
              message: 'please verify otp to take withdrawal',
            });
          } else {
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'You have not sufficient balance for withdrawal',
            });
          }
        } else {
          return await ResponseHelper({
            status: Status?.STATUS_FALSE,
            status_code: StatusCode?.HTTP_BAD_REQUEST,
            message: 'Your previous request already in process',
          });
        }
      } else {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_VALIDATION_ERROR,
          data: null,
        });
      }
    } catch (error) {
      console.log(error);
      await CatchErrorResponseHelper(error);
    }
  }

  async withdrawReqApproval(payload: any) {
    console.log('djdjj');
    try {
      const { userId, txnId, type, amount, reqId, withdrawGatewayType } =
        payload.body;

      const find_user = await this.UserModel.findById(userId);
      const find_txn = await this.TransactionModel.findById(txnId);
      // const find_txn = await this.WithdrawModel.findById(reqId);
      if (withdrawGatewayType == 'razorpay') {
        if (Number(find_user.withdraw_holdbalance) > 0 && type == 'upi') {
          if (find_txn.status == 1 || find_txn.status == 2) {
            return await ResponseHelper({
              status: Status?.STATUS_TRUE,
              status_code: StatusCode?.HTTP_OK,
              message: 'Payout Request already processed',
            });
          } else {
            let username = 'rzp_live_E6nN6AeCMOScBL';
            let password = 'pAAS6YIvGKt4NtvUhpOzfUEg';

            // (async () => {

            const options = {
              method: 'POST',
              url: 'https://api.razorpay.com/v1/payouts',
              auth: {
                username: username,
                password: password,
              },
              headers: {
                'content-type': 'application/json',
              },
              data: {
                account_number: '409002200430',
                amount: amount * 100,
                currency: 'INR',
                mode: 'UPI',
                purpose: 'payout',
                fund_account: {
                  account_type: 'vpa',
                  vpa: {
                    address: find_user.upi_id,
                  },
                  contact: {
                    name: find_user.holder_name.toString(),
                    email: find_user.email ? find_user.email.toString() : '',
                    contact: find_user.phone_number
                      ? find_user.phone_number.toString()
                      : '',
                    type: 'self',
                    reference_id: find_user._id.toString(),
                  },
                },
                queue_if_low_balance: true,
                reference_id: find_txn._id,
              },
            };

            await axios
              .request(options)
              .then(async function (response) {
                if (response.data.status === 'processed') {
                  find_txn.referenceId = response.data.id;
                  find_txn.status = 1;
                  find_txn.action_by = 'req.user.id';
                  find_txn.client_ip = 'clientIp';
                  find_txn.client_forwarded_ip = 'clientForwardedIp';
                  find_txn.client_remote_ip = 'clientRemoteIp';

                  if (find_user.withdraw_holdbalance >= find_txn.amount) {
                    find_user.totalWithdrawl =
                      Number(find_user.totalWithdrawl) +
                      Number(find_txn.amount);
                    find_user.withdraw_holdbalance =
                      Number(find_user.withdraw_holdbalance) -
                      Number(find_txn.amount);
                  }

                  find_user.lastWitdrawl = Date.now();
                  find_user.save();
                  find_txn.save();

                  find_txn.closing_balance =
                    Number(find_txn.closing_balance) -
                    Number(find_txn.amount);
                  find_txn.status = 1;
                  find_txn.save();

                  return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: 'Your withdrawal request successfully completed',
                  });
                } else if (
                  response.data.status === 'pending' ||
                  response.data.status === 'queued' ||
                  response.data.status === 'processing'
                ) {
                  find_txn.referenceId = response.data.id;
                  find_txn.status = 0;
                  // find_txn.action_by = req.user.id;

                  // txn.client_ip = clientIp;
                  // txn.client_forwarded_ip = clientForwardedIp;
                  // txn.client_remote_ip = clientRemoteIp;

                  find_txn.save();
                  find_user.save();

                  find_txn.closing_balance =
                    Number(find_txn.closing_balance) -
                    Number(find_txn.amount);
                  find_txn.status = 0;
                  find_txn.save();

                  return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: 'Your withdrawal request in proccessing',
                  });
                } else if (
                  response.data.status === 'rejected' ||
                  response.data.status === 'cancelled'
                ) {
                  find_txn.referenceId = response.data.id;
                  find_txn.status = 2;
                  // find_txn.action_by = req.user.id;
                  find_txn.txn_msg =
                    'issuer bank or payment service provider declined the transaction';

                  //   find_txn.client_ip = clientIp;
                  //   find_txn.client_forwarded_ip = clientForwardedIp;
                  //   find_txn.client_remote_ip = clientRemoteIp;

                  if (find_user.withdraw_holdbalance >= find_txn.amount) {
                    find_user.Wallet_balance =
                      Number(find_user.Wallet_balance) +
                      Number(find_txn.amount);
                    find_user.withdrawAmount =
                      Number(find_user.withdrawAmount) +
                      Number(find_txn.amount);
                    find_user.withdraw_holdbalance =
                      Number(find_user.withdraw_holdbalance) -
                      Number(find_txn.amount);
                  }
                  find_user.save();
                  find_txn.save();

                  find_txn.closing_balance =
                    Number(find_txn.closing_balance) +
                    Number(find_txn.amount);
                  find_txn.status = 2;
                  find_txn.save();

                  return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: 'Your withdrawal request failed',
                  });
                }
              })
              .catch(async function (error) {
                console.error(error, 'rozerpay');
                find_txn.status = 2;
                find_txn.action_by = '';
                find_txn.txn_msg =
                  'Withdraw request failed due to technical issue, try after some time.';

                find_txn.client_ip = 'clientIp';
                find_txn.client_forwarded_ip = 'clientForwardedIp';
                find_txn.client_remote_ip = 'clientRemoteIp';

                if (find_user.withdraw_holdbalance >= find_txn.amount) {
                  find_user.Wallet_balance =
                    Number(find_user.Wallet_balance) + Number(find_txn.amount);
                  find_user.withdrawAmount =
                    Number(find_user.withdrawAmount) + Number(find_txn.amount);
                  find_user.withdraw_holdbalance =
                    Number(find_user.withdraw_holdbalance) -
                    Number(find_txn.amount);
                }
                find_user.save();
                find_txn.save();

                find_txn.closing_balance =
                  Number(find_txn.closing_balance) +
                  Number(find_txn.amount);
                find_txn.status = 2;
                find_txn.save();

                return await ResponseHelper({
                  status: Status?.STATUS_TRUE,
                  status_code: StatusCode?.HTTP_OK,
                  message: 'Your withdrawal request failed',
                });
              });
            // })();
            find_txn.save();
            find_user.save();
          }
        } else if (
          Number(find_user.withdraw_holdbalance) > 0 &&
          type == 'bankTransfers'
        ) {
          if (find_user.rzp_fund_acc == null || find_user.rzp_contact == null) {
            return await ResponseHelper({
              status: Status?.STATUS_FALSE,
              status_code: StatusCode?.HTTP_BAD_REQUEST,
              message: 'fund account not added',
            });
          }

          if (find_txn.status == 1 || find_txn.status == 2) {
            return await ResponseHelper({
              status: Status?.STATUS_TRUE,
              status_code: StatusCode?.HTTP_OK,
              message: 'Payout Request already processed',
            });
          } else {
            let username = 'rzp_live_E6nN6AeCMOScBL';
            let password = 'pAAS6YIvGKt4NtvUhpOzfUEg';

            // (async () => {

            const options = {
              method: 'POST',
              url: 'https://api.razorpay.com/v1/payouts',
              auth: {
                username: username,
                password: password,
              },
              headers: {
                'content-type': 'application/json',
              },
              data: {
                account_number: '409002200430',
                fund_account_id: find_user.rzp_fund_acc,
                amount: amount * 100,
                currency: 'INR',
                mode: 'IMPS',
                purpose: 'payout',
                queue_if_low_balance: true,
                reference_id: find_txn._id,
                narration: 'Acme Corp Fund Transfer',
                notes: {},
              },
            };

            await axios
              .request(options)
              .then(async function (response) {
                if (response.data.status === 'processed') {
                  find_txn.referenceId = response.data.id;
                  find_txn.status = 1;
                  find_txn.action_by = 'req.user.id';

                  find_txn.client_ip = 'clientIp';
                  find_txn.client_forwarded_ip = 'clientForwardedIp';
                  find_txn.client_remote_ip = 'clientRemoteIp';


                  // this.forwithdrawDone(userId, txnId);

                  if (find_user.withdraw_holdbalance >= find_txn.amount) {
                    find_user.totalWithdrawl =
                      Number(find_user.totalWithdrawl) +
                      Number(find_txn.amount);
                    find_user.withdraw_holdbalance =
                      Number(find_user.withdraw_holdbalance) -
                      Number(find_txn.amount);
                  }

                  find_user.lastWitdrawl = Date.now();
                  find_user.save();
                  find_txn.save();

                  find_txn.closing_balance =
                    Number(find_txn.closing_balance) -
                    Number(find_txn.amount);
                  find_txn.status = 1;
                  find_txn.save();

                  return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: 'Your withdrawal request successfully completed',
                  });
                } else if (
                  response.data.status === 'pending' ||
                  response.data.status === 'queued' ||
                  response.data.status === 'processing'
                ) {
                  find_txn.referenceId = response.data.id;
                  find_txn.status = 0;
                  find_txn.action_by = 'req.user.id';

                  find_txn.client_ip = 'clientIp';
                  find_txn.client_forwarded_ip = 'clientForwardedIp';
                  find_txn.client_remote_ip = 'clientRemoteIp';

                  find_txn.save();
                  find_user.save();

                  find_txn.closing_balance =
                    Number(find_txn.closing_balance) -
                    Number(find_txn.amount);
                  find_txn.status = 0;
                  find_txn.save();

                  return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: 'Your withdrawal request in proccessing',
                  });
                } else if (
                  response.data.status === 'rejected' ||
                  response.data.status === 'cancelled'
                ) {
                  find_txn.referenceId = response.data.id;
                  find_txn.status = 2;
                  find_txn.action_by = 'req.user.id';
                  find_txn.txn_msg =
                    'issuer bank or payment service provider declined the transaction';

                  find_txn.client_ip = 'clientIp';
                  find_txn.client_forwarded_ip = 'clientForwardedIp';
                  find_txn.client_remote_ip = 'clientRemoteIp';

                  if (find_user.withdraw_holdbalance >= find_txn.amount) {
                    find_user.Wallet_balance =
                      Number(find_user.Wallet_balance) +
                      Number(find_txn.amount);
                    find_user.withdrawAmount =
                      Number(find_user.withdrawAmount) +
                      Number(find_txn.amount);
                    find_user.withdraw_holdbalance =
                      Number(find_user.withdraw_holdbalance) -
                      Number(find_txn.amount);
                  }
                  find_user.save();
                  find_txn.save();

                  find_txn.closing_balance =
                    Number(find_txn.closing_balance) +
                    Number(find_txn.amount);
                  find_txn.status = 2;
                  find_txn.save();

                  return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    message: 'Your withdrawal request failed',
                  });
                }
              })
              .catch(async function (error) {
                console.error(error, 'rozerpay');
                find_txn.status = 2;
                find_txn.action_by = '';
                find_txn.txn_msg =
                  'Withdraw request failed due to technical issue, try after some time.';

                find_txn.client_ip = 'clientIp';
                find_txn.client_forwarded_ip = 'clientForwardedIp';
                find_txn.client_remote_ip = 'clientRemoteIp';

                if (find_user.withdraw_holdbalance >= find_txn.amount) {
                  find_user.Wallet_balance =
                    Number(find_user.Wallet_balance) + Number(find_txn.amount);
                  find_user.withdrawAmount =
                    Number(find_user.withdrawAmount) + Number(find_txn.amount);
                  find_user.withdraw_holdbalance =
                    Number(find_user.withdraw_holdbalance) -
                    Number(find_txn.amount);
                }
                find_user.save();
                find_txn.save();

                find_txn.closing_balance =
                  Number(find_txn.closing_balance) +
                  Number(find_txn.amount);
                find_txn.status = 2;
                find_txn.save();

                return await ResponseHelper({
                  status: Status?.STATUS_TRUE,
                  status_code: StatusCode?.HTTP_OK,
                  message: 'Your withdrawal request failed',
                });
              });
            // })();
            find_txn.save();
            find_user.save();
          }
        }
      } else if (withdrawGatewayType == 'MYPAY') {
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async userWithdrawVerify(payload: any) {
    try {
      const { userId, OTP, txnId, withdrawGatewayType } = payload.body;
      const find_user = await this.UserModel.findById(userId);
      const find_txn = await this.TransactionModel.findById(txnId);
      // const find_txn = await this.WithdrawModel.findOne({
      //   txn_id: txnId,
      // });
      console.log('object');

      let autoWithdraw = {
        body: {
          userId: userId,
          txnId: find_txn.id,
          type: find_txn.payment_methode,
          amount: find_txn.amount,
          reqId: find_txn.id,
          withdrawGatewayType: withdrawGatewayType,
        },
      };

      if (find_txn.withdrawOtp == OTP) {
        if (find_txn.withdrawType == 'Auto') {
          this.withdrawReqApproval(autoWithdraw);
        } else {
          await this.forwithdrawReq(find_user.id, find_txn.amount);
          find_txn.withdrawVerified = true;
          find_txn.save();

          return await ResponseHelper({
            status: Status?.STATUS_TRUE,
            status_code: StatusCode?.HTTP_OK,
            data: find_txn,
            message: 'Your withdraw request submited successfully',
          });
        }
      } else {
        find_txn.withdrawVerified = false;
        find_txn.status = 2;
        find_txn.save();
        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          message: 'OTP not match',
        });
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  async userTransactionHistory(payload: any) {
    console.log('j');
    try {
      const { startdate, enddate, type, page, pageSize } = payload.body;
      let skip = (page - 1) * pageSize;
      const loginUser = payload?.loginUser;
      let filter: any = {};
      if (loginUser.id) {
        filter.user_id = loginUser.id;
      }
      if (startdate && enddate) {
        filter.createdAt = {
          $gte: new Date(startdate),
          $lte: moment(enddate).endOf('day'),
        };
      }
      if (type) {
        filter.req_type = type;
      } else if (!type) {
        filter.req_type = { $in: ['withdrawal', 'deposit'] };
      }
      console.log(filter);
      const find_txn = await this.TransactionModel.find(filter)
        .skip(skip)
        .limit(pageSize);
      const count = await this.TransactionModel.countDocuments(filter);
      if (find_txn) {
        let data = { row: find_txn, count };

        return await ResponseHelper({
          status: Status?.STATUS_TRUE,
          status_code: StatusCode?.HTTP_OK,
          data: data,
        });
      } else {
        return await ResponseHelper({
          status: Status?.STATUS_FALSE,
          status_code: StatusCode?.HTTP_BAD_REQUEST,
          message: 'No transaction found',
        });
      }
    } catch (error) {
      await CatchErrorResponseHelper(error);
    }
  }

  // changes in user schema commom used
  async forwithdrawReq(userId: any, amount: any) {
    const find_user: any = await this.UserModel.findById(userId);
    if (find_user) {
      find_user.Wallet_balance -= amount;
      find_user.withdrawAmount -= amount;
      find_user.withdraw_holdbalance += parseFloat(amount);

      find_user.save();
    }
  }

  // changes in user schema commom used
  async forwithdrawDone(userId: any, txnId: any) {
    const find_user = await this.UserModel.findById(userId);
    const find_txn = await this.TransactionModel.findById(txnId);

    if (find_user && find_txn) {
      if (find_user.withdraw_holdbalance >= find_txn.amount) {
        find_user.totalWithdrawl =
          Number(find_user.totalWithdrawl) + Number(find_txn.amount);
        find_user.withdraw_holdbalance =
          Number(find_user.withdraw_holdbalance) - Number(find_txn.amount);
      }
      find_user.lastWitdrawl = Date.now();
      find_user.save();
    }
  }
}

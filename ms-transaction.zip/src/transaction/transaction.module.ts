import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Transaction, TransactionSchema } from 'src/schema/transaction.schema';
import { Withdraw , WithdrawSchema } from 'src/schema/withdraw.schema';
import { Users, UsersSchema } from 'src/schema/users.schema';
import { TransactionController } from './transaction.controller';
import { TransactionService } from './transaction.service';
import { BanckDetails, BanckDetailsSchema } from 'src/schema/bank_details.schema';
// import { MainAdmin, MainAdminSchema } from 'src/schema/main_admin.schema';




@Module({
    imports: [MongooseModule.forFeature([
        { name: Users.name, schema: UsersSchema },
        { name: Transaction.name, schema: TransactionSchema },
        { name: Withdraw.name, schema: WithdrawSchema },
        { name: BanckDetails.name, schema: BanckDetailsSchema },

    ])],
    controllers: [TransactionController],
    providers: [TransactionService]
})
export class TransactionModule { }

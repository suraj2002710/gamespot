import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { CommonConfig } from './config/CommanConfig';
import { TransactionModule } from './transaction/transaction.module';
import { AdminTransactionModule } from './admin_transaction/transaction.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal:true
    }),
    MongooseModule.forRootAsync({
      useFactory: async () => ({
        uri: CommonConfig.MONGODB_URL
      })
    }),
    TransactionModule,
    AdminTransactionModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

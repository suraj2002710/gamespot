import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Transport } from '@nestjs/microservices';
import { CommonConfig } from './config/CommanConfig';

async function bootstrap() {
  const app = await NestFactory.createMicroservice(AppModule,{
    transport: Transport.TCP,
    options:{
      host: <any>CommonConfig?.HOST_TRANSACTION,
      port: <any>CommonConfig?.PORT_TRANSACTION,
    }
  });
  await app.listen();
}
bootstrap();

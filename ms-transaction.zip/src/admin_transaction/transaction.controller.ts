import { Body, Controller } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { AdminTransactionService } from './transaction.service';

@Controller('transaction')
export class AdminTransactionController {
    constructor(private readonly AdminTransactionService: AdminTransactionService) { }

    @MessagePattern({ cmd: "get_transaction_list" })
    async get_all_user(@Body() body: any) {
        return await this.AdminTransactionService.get_transaction_lists(body)
    }

    @MessagePattern({ cmd: "withdraw_request_List" })
    async withdrawle_request_List(@Body() body: any) {
        return await this.AdminTransactionService.withdrawle_request_List(body)
    }

    // @MessagePattern({ cmd: "accpect_withdrawle" })
    // async accpect_withdrawle(@Body() body: any) {
    //     return await this.AdminTransactionService.accpect_withdrawle(body)
    // }
    @MessagePattern({ cmd: "get_single_transaction" })
    async get_single_transaction(@Body() body: any) {
        return await this.AdminTransactionService.get_single_transaction(body)
    }


}

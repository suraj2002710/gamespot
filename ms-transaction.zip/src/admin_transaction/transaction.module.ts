import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Transaction, TransactionSchema } from 'src/schema/transaction.schema';
import { Users, UsersSchema } from 'src/schema/users.schema';
import { Withdraw , WithdrawSchema } from 'src/schema/withdraw.schema';
import { AdminTransactionController } from './transaction.controller';
import {  AdminTransactionService } from './transaction.service';
// import { MainAdmin, MainAdminSchema } from 'src/schema/main_admin.schema';




@Module({
    imports: [MongooseModule.forFeature([
        { name: Users.name, schema: UsersSchema },
        { name: Transaction.name, schema: TransactionSchema },
        { name: Withdraw.name, schema: WithdrawSchema },
        // { name: MainAdmin.name, schema: MainAdminSchema },

    ])],
    controllers: [AdminTransactionController],
    providers: [AdminTransactionService]
})
export class AdminTransactionModule { }

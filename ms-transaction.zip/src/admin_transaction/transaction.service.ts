import { Injectable } from '@nestjs/common';
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import * as moment from 'moment';
import { Status, StatusCode } from "src/constants/HttpConstant";
import { MessageConstant } from "src/constants/MessageConstant";

import { CatchErrorResponseHelper, QueryErrorResponseHelper, ResponseHelper } from "src/utils/Response";
import { Transaction } from 'src/schema/transaction.schema';
import { Users } from 'src/schema/users.schema';
import { Withdraw } from 'src/schema/withdraw.schema';
// import { MainAdmin } from 'src/schema/main_admin.schema';

@Injectable()
export class AdminTransactionService {

    constructor(
        @InjectModel(Users.name) private readonly UsersService: Model<Users>,
        @InjectModel(Transaction.name) private readonly Transactionservice: Model<Transaction>,
        @InjectModel(Withdraw.name)
    private readonly WithdrawModel: Model<Withdraw>,

    ) { }

    async get_transaction_lists(payload: any) {
        try {
            const { userid, startdate, enddate, type, page, pageSize } = payload.body
            let skip = (page - 1) * pageSize
            let filter: any = {}
            if (userid) {
                filter.user_id = userid
            }
            if (startdate && enddate) {
                filter.createdAt = {
                    $gte: new Date(startdate), $lte: moment(enddate).endOf("day")
                }
            }
            if (type) {
                filter.req_type = type
            }
            if (!type) {
                filter.req_type = { $in: ['withdrawal', 'deposit'] }
            }
            console.log(filter)
            const find_user = await this.Transactionservice.find(filter).skip(skip).limit(pageSize)
            const count = await this.Transactionservice.countDocuments(filter)
            if (find_user) {
                let data = { row: find_user, count }

                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data: data
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                message: "no transaction"
            });

        } catch (error) {
            await CatchErrorResponseHelper(error);

        }
    }


    async withdrawle_request_List(payload: any) {
        try {
 console.log("withdrawle_request_List");

            const {status} = payload.body

            const find_withdraw = await this.Transactionservice.find({ status: 0 })


            if (find_withdraw) {

                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data:find_withdraw,
                    message: `withdraw request found`,
                });
            } else {
                await QueryErrorResponseHelper({
                    code: StatusCode?.HTTP_BAD_REQUEST,
                    message: `withdraw request ${MessageConstant?.IS_NOT_FOUND}`
                }, {
                    custom_code: StatusCode?.HTTP_BAD_REQUEST,
                    custom_message: `Agent ${MessageConstant?.IS_NOT_FOUND}`
                });
            }


        } catch (error) {
            console.log('error>>>', error)
            await CatchErrorResponseHelper(error);
        }
    }

    // async accpect_withdrawle(payload: any) {
    //     try {

    //         console.log("wihdrawle");

    //         const { transaction_id, status } = payload.body

    //         const transection: any = await this.Transactionservice.findOne({ _id: transaction_id })


    //         if (transection) {



    //             if (transection.status != 1 && status == 1) {


    //                 const updatetransaction = await this.Transactionservice.findByIdAndUpdate({ _id: transaction_id }, { $set: { status: 1, updatedAt: new Date(Date.now()) } })
    //                 return await ResponseHelper({
    //                     status: Status?.STATUS_TRUE,
    //                     status_code: StatusCode?.HTTP_OK,
    //                     message: `withdraw Accpect`,
    //                 });

    //             } else if (transection.status != 2 && status == 2) {
    //                 const updatetransaction = await this.Transactionservice.findByIdAndUpdate({ _id: transaction_id }, { $set: { status: 2, updatedAt: new Date(Date.now()) } })
    //                 return await ResponseHelper({
    //                     status: Status?.STATUS_TRUE,
    //                     status_code: StatusCode?.HTTP_OK,
    //                     message: `withdraw decline`,
    //                 });
    //             }
    //             else if (transection.status != 3 && status == 3) {
    //                 const updatetransaction = await this.Transactionservice.findByIdAndUpdate({ _id: transaction_id }, { $set: { status: 3, updatedAt: new Date(Date.now()) } })
    //                 return await ResponseHelper({
    //                     status: Status?.STATUS_TRUE,
    //                     status_code: StatusCode?.HTTP_OK,
    //                     message: `withdraw on hold`,
    //                 });
    //             } else {
    //                 return await ResponseHelper({
    //                     status: Status?.STATUS_TRUE,
    //                     status_code: StatusCode?.HTTP_OK,
    //                     message: `invalid request or already proceed`,
    //                 });
    //             }
    //         } else {
    //             await QueryErrorResponseHelper({
    //                 code: StatusCode?.HTTP_BAD_REQUEST,
    //                 message: `Agent ${MessageConstant?.IS_NOT_FOUND}`
    //             }, {
    //                 custom_code: StatusCode?.HTTP_BAD_REQUEST,
    //                 custom_message: `Agent ${MessageConstant?.IS_NOT_FOUND}`
    //             });
    //         }


    //     } catch (error) {
    //         console.log('error>>>', error)
    //         await CatchErrorResponseHelper(error);
    //     }
    // }


    async get_single_transaction(payload: any) {
        try {
            const {transaction_id } = payload.params
            
            const find_user = await this.Transactionservice.findOne({_id:transaction_id})
            
            if (find_user) {
                let data = { row: find_user }

                return await ResponseHelper({
                    status: Status?.STATUS_TRUE,
                    status_code: StatusCode?.HTTP_OK,
                    data: data
                });
            }
            return await ResponseHelper({
                status: Status?.STATUS_FALSE,
                status_code: StatusCode?.HTTP_BAD_REQUEST,
                message: "no transaction"
            });

        } catch (error) {
            await CatchErrorResponseHelper(error);

        }
    }




}

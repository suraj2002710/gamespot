import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Users } from "./users.schema";
import mongoose, { HydratedDocument } from "mongoose";

export type BanckDetailsDocument = HydratedDocument<BanckDetails>

@Schema()
export class BanckDetails {

    @Prop()
    accountNumber: string;

    @Prop()
    upi: string;

    @Prop({ required: true,enum:['bank','upi'] })
    type: string;

    @Prop({ required: true, ref: "Users", type: mongoose.Schema.Types.ObjectId })
    User_Id: Users;

    @Prop()
    bankName: string;

    @Prop({ required: true })
    account_holder_name: string;

    @Prop()
    ifsc_code: string;

    @Prop()
    branch_name: string;

    @Prop({default: false})
    otpVerified: Boolean;

    @Prop()
    bankOTP: String;
    
    @Prop({ default: 'unverified', enum:['unverified', 'Pending' ,'verified']} )
    verified: String;

    @Prop({ default: "" })  //0=pending,1=accpeted 2=rejected
    verified_reason: String;
}

export const BanckDetailsSchema = SchemaFactory.createForClass(BanckDetails)
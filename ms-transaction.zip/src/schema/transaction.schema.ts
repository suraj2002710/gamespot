import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

import mongoose, { HydratedDocument } from 'mongoose';
import { Users } from './users.schema';

export type TransactionDocument = HydratedDocument<Transaction>;

@Schema({ timestamps: true })
export class Transaction {
    @Prop()
    cf_order_id: string;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Users' })
    user_id: Users;


    @Prop({ required: true })
    amount: Number;

    @Prop()
    bonus_id: String;

    @Prop()
    upi_id: string;

    @Prop()
    closing_balance: Number;

    @Prop({ enum: ['upi', 'card', 'bankTransfer']})
    payment_methode: string;   //upi, card, banktransfer

    @Prop()
    payment_gatway: string;   
    
    @Prop({ enum: ['withdrawal', 'deposit', 'bonus', 'penalty'], required: true })
    req_type: string;

    @Prop({ required: false })
    withdrawVerified: boolean;

    @Prop({ enum: ['Auto', 'Manual']})
    withdrawType: string;  

    @Prop()
    withdrawOtp: string;
     
    @Prop()
    account_no: string;

    @Prop()
    ifsc_code: string;

    @Prop()
    account_holder: string;

    @Prop()
    client_ip: string;
    @Prop()
    client_forwarded_ip: string;
    
    @Prop()
    client_remote_ip: string;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Agent' })
    action_by: string;
    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Agent' })
    varified_by: string;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Users' })
    referred_by: Users;

    @Prop({ enum: [0, 1, 2, 3, 4], default: 0 })  //0 => Pending, 1 => 'Paid', 2 =>'Failed', 3 =>'hold', 
    status: number;

    @Prop()
    Status_reason: string;

    @Prop()
    order_id: string;

    @Prop()
    referenceId: string;

    @Prop()
    txn_msg: string;

    @Prop()
    transaction_id: Number;

}

export const TransactionSchema = SchemaFactory.createForClass(Transaction);
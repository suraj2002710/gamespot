import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

import mongoose, { HydratedDocument } from 'mongoose';
import { Users } from './users.schema';

export type WithdrawDocument = HydratedDocument<Withdraw>;

@Schema({ timestamps: true })
export class Withdraw {

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Users' })
    user_id: Users;

    @Prop({ required: true })
    amount: Number;

    @Prop()
    upi_id: string;

    @Prop({default:0})
    closing_balance: Number;

    @Prop({ enum: ['upi', 'card', 'bankTransfer']})
    payment_methode: string;   //upi, card, banktransfer

    @Prop()
    payment_gatway: string;   
    
    @Prop({ enum: ['withdrawal', 'deposit'], required: true })
    req_type: string;

    @Prop()
    account_no: string;

    @Prop()
    ifsc_code: string;

    @Prop()
    account_holder: string;

    @Prop({ enum: [0, 1, 2, 3, 4], default: 0 })  //0 => Pending, 1 => 'Paid', 2 =>'Failed', 3 =>'hold', 
    status: number;

    @Prop()
    order_id: string;

    @Prop()
    referenceId: string;

    @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'Treansaction' })
    txn_id: string;

}

export const WithdrawSchema = SchemaFactory.createForClass(Withdraw);
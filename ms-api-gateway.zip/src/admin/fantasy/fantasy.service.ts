import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";
import { InjectModel } from "@nestjs/mongoose";



@Injectable()
export class FantasyService{
    constructor(@Inject("FANTASY_MICROSERVICES") private authClientProxy: ClientProxy) { }

    

    async create_tournaments(payload: any) {
        return await this.authClientProxy.send({ cmd: 'create_tournaments' }, payload);
    }
    async create_contestType(payload: any) {
        return await this.authClientProxy.send({ cmd: 'create_contestType' }, payload);
    }
    async createTeam(payload: any) {
        return await this.authClientProxy.send({ cmd: 'createTeam' }, payload);
    }
    async createPlayer(payload: any) {
        return await this.authClientProxy.send({ cmd: 'createPlayer' }, payload);
    }

    async fetchAndStoreMatches(payload: any) {
        return await this.authClientProxy.send({ cmd: 'fetchAndStoreMatches' }, payload);
    }


}
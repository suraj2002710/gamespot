import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class KycService {
    constructor(@Inject("USER_MICROSERVICES") readonly authClientProxy: ClientProxy) { }

    async kyc_list(payload: any) {
        return await this.authClientProxy.send({ cmd: 'kyc_list' }, payload);
    }

    async kyc_accpect(payload: any) {
        return await this.authClientProxy.send({ cmd: 'kyc_accpect' }, payload);
    }

}
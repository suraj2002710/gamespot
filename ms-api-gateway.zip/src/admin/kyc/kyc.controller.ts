import { Controller, Post, Req } from "@nestjs/common";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { KycService } from "./kyc.service";


@Controller(`${CommonConfig.API_ADMIN_URL}kyc`)
export class AdminKycController {
    constructor(private readonly KycService: KycService) { }
    @Post("kyc_list")
    async BankDetail_approval(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.KycService.kyc_list(getPayload);
    }

    @Post("kyc_accpect")
    async kyc_accpect(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.KycService.kyc_accpect(getPayload);
    }
}
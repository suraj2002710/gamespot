import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class AdminUsersService{
    constructor(
        @Inject("USER_MICROSERVICES") readonly authClientProxy: ClientProxy,
        @Inject("ADMIN_MICROSERVICES") readonly adminClientProxy:ClientProxy
    ){}

    async get_all_users(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'get_all_users' }, payload);
    }
    
    async edit_user(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'edit_user' }, payload);
    }
    async block_unblock_user(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'block_unblock_user' }, payload);
    }
    async add_bonus(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'add_bonus' }, payload);
    }
    async add_palenty(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'add_palenty' }, payload);
    }
    async send_user_notification(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'send_user_notification' }, payload);
    }
    async get_single_user(payload: any) {
        return await this.adminClientProxy.send({ cmd: 'get_single_user' }, payload);
    }

}
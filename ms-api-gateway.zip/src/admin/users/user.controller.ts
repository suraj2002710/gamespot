import { Controller, Get, Post, Req, UseInterceptors } from "@nestjs/common";
import { AdminUsersService } from "./usrs.service";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { FileInterceptor } from "@nestjs/platform-express";


@Controller(`${CommonConfig.API_ADMIN_URL}user`)
export class AdminUsersController{
    constructor(private readonly AdminUsersService: AdminUsersService){}
    @Post("get_all_users")
    async BankDetail_approval(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.get_all_users(getPayload);
    }

    @Get("single-user/:user_id")
    async get_single_user(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.get_single_user(getPayload);
    }
    @UseInterceptors(FileInterceptor('profile'))
    @Post("edit_user")
    async edit_user(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.edit_user(getPayload);
    }


    
    @Post("block-unblock-user")
    async block_unblock_user(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.block_unblock_user(getPayload);
    }


    @Post("add_bonus")
    async add_bonus(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.add_bonus(getPayload);
    }

    @Post("add_palenty")
    async add_palenty(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.add_palenty(getPayload);
    }

    @Post("send_user_notification")
    async send_user_notification(@Req() request: any) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AdminUsersService.send_user_notification(getPayload);
    }
}
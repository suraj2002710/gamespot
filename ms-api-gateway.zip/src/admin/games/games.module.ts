import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";

import { AdminGamesService } from "./games.service";
import { AdminUsersController } from "./games.controller";

@Module({
    imports: [ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name: 'GAME_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig.HOST_GAME,
                port: <any>CommonConfig.PORT_GAME
            }
        },
    ])],
    providers: [AdminGamesService],
    controllers: [AdminUsersController]
})
export class AdminGamesModule { }
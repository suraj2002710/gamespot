import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";

import { AdminTransactionService } from "./transaction.service";
import { AdminTransactionController } from "./transaction.controller";

@Module({
    imports: [ConfigModule.forRoot(),
    ClientsModule.register([
        {
            name: 'TRANSACTION_MICROSERVICES',
            transport: Transport.TCP,
            options: {
                host: <any>CommonConfig?.HOST_TRANSACTION,
                port: <any>CommonConfig?.PORT_TRANSACTION
            }
        },
    ])],
    providers: [AdminTransactionService],
    controllers: [AdminTransactionController]
})
export class AdminTransactionModule { }
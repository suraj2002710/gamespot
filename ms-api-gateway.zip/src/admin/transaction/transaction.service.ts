import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class AdminTransactionService {
    constructor(@Inject("TRANSACTION_MICROSERVICES") readonly authClientProxy: ClientProxy) { }

    async get_with_drawle_request(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_transaction_list' }, payload);
    }

    async accpect_withdrawle(payload: any) {
        return await this.authClientProxy.send({ cmd: 'accpect_withdrawle' }, payload);
    }
           
    async get_single_transaction(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_single_transaction' }, payload);
    }

    async get_withdrawle_request_List(payload: any) {
        return await this.authClientProxy.send({ cmd: 'withdraw_request_List' }, payload);
    }

    async withdraw_request_approval(payload: any) {
        return await this.authClientProxy.send({ cmd: 'withdraw_request_approval' }, payload);
    }
}
import { Body, Controller, Post, Req } from "@nestjs/common";
import { Super_Admin_Kyc_Service } from "./kyc.service";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";


@Controller(`${CommonConfig.API_MAIN_ADMIN_URL}kyc`)
export class Super_Admin_Kyc_Controller{
    constructor(private readonly Super_Admin_Kyc_Service: Super_Admin_Kyc_Service){}

    @Post("kyc-approval")
    async kyc_approval(@Req() request:any){
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.Super_Admin_Kyc_Service.kyc_approval(getPayload);
    }

}
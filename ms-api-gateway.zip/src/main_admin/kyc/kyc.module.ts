import { Module } from "@nestjs/common";
import { Super_Admin_Kyc_Service } from "./kyc.service";
import { Super_Admin_Kyc_Controller } from "./kyc.controller";
import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";


@Module({
    imports: [ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'MAIN_ADMIN_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                    host: <any>CommonConfig?.HOST_MAIN_ADMIN,
                    port: <any>CommonConfig?.PORT_MAIN_ADMIN
                }
            },
        ]),],
    controllers:[Super_Admin_Kyc_Controller],
    providers:[Super_Admin_Kyc_Service]
})
export class Super_Admin_Kyc_Module{}
import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class Game_Category_Service {

    constructor(@Inject("MAIN_ADMIN_MICROSERVICES") readonly authclientProxy:ClientProxy) {
        
    }

    async create_Category(payload:any){
        return this.authclientProxy.send({ cmd: "create_category" }, payload)
    }
    async update_Category(payload:any){
        return this.authclientProxy.send({ cmd: "update_Category" }, payload)
    }
    async delete_Category(payload:any){
        return this.authclientProxy.send({ cmd: "delete_Category" }, payload)
    }
    async get_single_Category(payload:any){
        return this.authclientProxy.send({ cmd: "get_single_Category" }, payload)
    }
    async get_all_Category(payload:any){
        return this.authclientProxy.send({ cmd: "get_all_Category" }, payload)
    }

}
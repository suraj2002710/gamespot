import { Controller, Post, Req, UseInterceptors } from "@nestjs/common";
import { AdminGameService } from "./game.service";
import { PayloadHelper } from "src/utils/Payload";
import { FileInterceptor } from "@nestjs/platform-express";
import { CommonConfig } from "src/config/CommanConfig";

@Controller(`${CommonConfig.API_MAIN_ADMIN_URL}games`)
export class AdminGamesController{
    constructor(private readonly GameService:AdminGameService){}

    @Post("game-create")
    @UseInterceptors(FileInterceptor('image',{
        limits:{fileSize: 2*1024*1024},
        fileFilter:function(req,file,cb){
            if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)){
                cb(null, true);
            }
            else {
                cb(new Error('Invalid file type'), false);
            }
        }
    }))
    async game_create(@Req() request:any){
        const payload=await PayloadHelper(request)
        return await this.GameService.create_game(payload)
    }

    @Post("game-update")
    @UseInterceptors(FileInterceptor('image',{
        limits:{fileSize: 2*1024*1024},
        fileFilter:function(req,file,cb){
            if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)){
                cb(null, true);
            }
            else {
                cb(new Error('Invalid file type'), false);
            }
        }
    }))
    async updateGame(@Req() request:any){
        const payload=await PayloadHelper(request)
        return await this.GameService.updateGame(payload)
    }

    @Post("game-get_all")
    async get_all_Game(@Req() request: any) {
        const payload = await PayloadHelper(request)
        return await this.GameService.get_all_Game(payload)
    }
    @Post("game-get_single")
    async get_single_Game(@Req() request: any) {
        const payload = await PayloadHelper(request)
        return await this.GameService.get_single_Game(payload)
    }
    @Post("game-delete")
    async delete_Game(@Req() request: any) {
        const payload = await PayloadHelper(request)
        return await this.GameService.delete_Game(payload)
    }
    
}
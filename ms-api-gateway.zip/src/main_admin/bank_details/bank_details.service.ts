import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";



@Injectable()
export class Super_Admin_BankDetail_Service {
    constructor(@Inject("MAIN_ADMIN_MICROSERVICES") private authClientProxy: ClientProxy
    ) { }
    async BankDetail_approval(payload: any) {
        return await this.authClientProxy.send({ cmd: 'approve_bank_details' }, payload);
    }
}
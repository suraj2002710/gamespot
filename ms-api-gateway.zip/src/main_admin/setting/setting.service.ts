import { Inject, Injectable } from "@nestjs/common"
import { JwtService } from "@nestjs/jwt";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class SettingServices {
    constructor(@Inject("MAIN_ADMIN_MICROSERVICES") private authClientProxy: ClientProxy
    ) { }

    async payment_gateway(payload: any) {
        return await this.authClientProxy.send({ cmd: 'payment_gateway' }, payload);
    }


}

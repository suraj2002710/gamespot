import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { CommonConfig } from './config/CommanConfig';
import { AuthModule } from './user/auth/auth.module';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { RerfealModule } from './user/referal/referal.module';
import { SettingModule } from './main_admin/setting/setting.module';
import { HMACModule } from './hmac/hmac.module';
import { User_KycModule } from './user/kyc/kyc.module';
import { UserNotificationModule } from './user/notification/notification.module';

import { Super_Admin_Kyc_Module } from './main_admin/kyc/kyc.module';
import { UserGamesModule } from './user/games/games.module';
import { Game_CategoryModule } from './main_admin/game_category/game_category.module';
import { Transaction_Module } from './user/transaction/trasnsaction.module';
import {  SuperAdminGamesModule } from './main_admin/game/game.module';
import { Super_Admin_BankDetail_Module } from './main_admin/bank_details/bank_details.module';
import { User_BankDetail_Module } from './user/bank_details/bank_details.module';
import { AdminAuthModule } from './admin/auth/auth.module';
import { SettingsModule } from './user/setting/setting.module';
import { AdminUserModule } from './admin/users/user.module';
import { AdminGamesModule } from './admin/games/games.module';
import { AdminKycModule } from './admin/kyc/kyc.module';
import { AdminTransactionModule } from './admin/transaction/transaction.module';
import { BannerModule } from './admin/banner/banner.module';
import { SocketModule } from './socket/socket.module';
import { FantasyModule } from './user/fantasy/fantasy.module';
import { AdminFantasyModule } from './admin/fantasy/fantasy.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal:true
    }),
    ClientsModule.register([
      {
        name: 'AUTH_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig?.HOST_AUTH,
          port: <any>CommonConfig?.PORT_AUTH
        }   
      },
      {
        name: 'USER_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig?.HOST_USER,
          port: <any>CommonConfig?.PORT_USER
        }
      },
      {
        name: 'MAIN_ADMIN_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig?.HOST_MAIN_ADMIN,
          port: <any>CommonConfig?.PORT_MAIN_ADMIN
        }
      },
      {
        name: 'TRANSACTION_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig?.HOST_TRANSACTION,
          port: <any>CommonConfig?.PORT_TRANSACTION
        }
      },
      {
        name: 'ADMIN_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig.HOST_ADMIN,
          port: <any>CommonConfig.PORT_ADMIN
        }
      },

      {
        name: 'GAME_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig.HOST_GAME,
          port: <any>CommonConfig.PORT_GAME
        }
      },

      {
        name: 'FANTASY_MICROSERVICES',
        transport: Transport.TCP,
        options: {
          host: <any>CommonConfig.HOST_FANTACY,
          port: <any>CommonConfig.PORT_FANTACY
        }
      },
    ]),

    MongooseModule.forRootAsync({ 
      useFactory:async()=>({
        uri: CommonConfig.MONGODB_URL
      })
    }),
    AuthModule,
    RerfealModule,
    HMACModule,
    
    User_KycModule,
    UserNotificationModule,
    Super_Admin_Kyc_Module,
    UserGamesModule,
    User_BankDetail_Module,
    SettingsModule,
    FantasyModule,
  
    SettingModule,
    Game_CategoryModule,
    Transaction_Module,
    SuperAdminGamesModule,
    Super_Admin_BankDetail_Module,
    AdminAuthModule,

    //Admin
    AdminUserModule,
    AdminGamesModule,
    AdminKycModule,
    AdminTransactionModule,
    BannerModule,
    AdminFantasyModule,


    //socket 
    SocketModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

// app.module.ts
import { Module } from '@nestjs/common';

import { HmacService } from './hmac.service';
import { HmacController } from './hmac.controller';

@Module({
    imports: [],
    controllers: [HmacController],
    providers: [HmacService],
})
export class HMACModule { }

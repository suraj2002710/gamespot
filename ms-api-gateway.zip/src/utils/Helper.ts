const request = require('request');
import { CommonConfig } from '../config/CommanConfig';
// import { FirebaseDynamicLinks } from 'firebase-dynamic-links';
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
import { InsertDBDateTimeHelper } from './DateTime';
import * as moment from "moment";
/* ==== Generate user name start ===== */
export const generateUsername = async (payload: any) => {
    var fname = '';
    var lname = '';
    var randomOne = Math.floor(10 + Math.random() * 99);
    var randomTwo = Math.floor(10 + Math.random() * 99);
    if (payload?.fname) {
        fname = payload?.fname;
        fname = fname.replace(/\s/g, '')
            .replace(/^\s+|\s+$/g, '')
            .replace(/[^a-zA-Z ]/g, '')
            .replace(/(?!\w|\s)./g, '')
            .replace(/\s+/g, '');

        fname = fname.substring(0, 3);
    }
    if (payload?.lname) {
        lname = payload?.lname;
        lname = lname.replace(/\s/g, '')
            .replace(/^\s+|\s+$/g, '')
            .replace(/[^a-zA-Z ]/g, '')
            .replace(/(?!\w|\s)./g, '')
            .replace(/\s+/g, '');

        lname = lname.substring(0, 3);
    }
    var userName = fname + lname + randomOne + payload?.id + randomTwo;
    userName = userName.toLowerCase();
    return userName;
}
/* ==== Generate user name end ===== */



async function upsertDbEvent(model: any, values: any, condition: any) {
    const obj = await model
        .findOne({ where: condition });
    //update
    if (obj)
        return obj.update(values);
    //insert
    return model.create(values);
}

export async function generateOTP() {
    if (CommonConfig?.IS_MAIL_WORKING != '1') {
        return '0000'
    }
    const min = 1000;
    const max = 9999;
    const otp = Math.floor(Math.random() * (max - min + 1)) + min;
    return otp.toString();
}

export async function validateEmail(email: any) {
    return String(email)
        .toLowerCase()
        .match(
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
};

export async function otpExpiryTime() {
    return moment().add(CommonConfig?.OTP_EXP_TIME_DIFF, 'minutes')
}
export async function checkOtpIsExpire(givenTime: any) {
    const date1 = moment(givenTime, 'YYYY-MM-DDTHH:mm:ss.SSSZ');
    const date2 = moment.utc();
    const duration = moment.duration(date2.diff(date1));
    const minutesDifference = duration.asMinutes();
    if (minutesDifference > CommonConfig?.OTP_EXP_TIME_DIFF) {
        return true
    }
    return false
}
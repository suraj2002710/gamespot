import { Inject, Injectable } from "@nestjs/common"
import { JwtService } from "@nestjs/jwt";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class ReferalServices {
    constructor(@Inject("USER_MICROSERVICES") private authClientProxy: ClientProxy
    ) { }

    async referal_code_update(payload: any) {
        return await this.authClientProxy.send({ cmd: 'referal_code_update' }, payload);
    }

    async get_referal_earning(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_referal_earning' }, payload);
    }

    async get_referal_history(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_referal_history' }, payload);
    }

    async reedem(payload: any) {
        return await this.authClientProxy.send({ cmd: 'reedem' }, payload);
    }
}
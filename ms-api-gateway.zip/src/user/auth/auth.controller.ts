import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";
import { AuthServices } from "./auth.service";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";

import { JwtAuthGuard } from "./gaurd/jwtguard";
import { FileInterceptor } from "@nestjs/platform-express";


@Controller(CommonConfig.API_URL)
export class AuthController{
    constructor(private readonly AuthServices:AuthServices){}
    @Post('sign-up')
    async sign_up(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.sign_up(getPayload);
    }

    @Post('login')
    async login(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.login(getPayload);
    }

    @UseGuards(JwtAuthGuard)
    @UseInterceptors(FileInterceptor('profile'))
    @Post('update-profile')
    async user_update_profile(@Req() request: Request) { 
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.update_profile(getPayload);
    }

    @UseGuards(JwtAuthGuard)
    @Get('get-profile')
    async get_profile(@Req() request: Request) { 
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.get_profile(getPayload);
    }

    
    @Post('forgot_password')
    async forgot_password(@Req() request: Request) { 
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.forgot_password(getPayload);
    }

    @Post('forgot_password_otp_verify')
    async verify_email_and_phone(@Req() request: Request) { 
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.forgot_password_otp_verify(getPayload);
    }

 
    @Post('reset_password')
    async reset_password(@Req() request: Request) { 
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.reset_password(getPayload);
    }

    @UseGuards(JwtAuthGuard)
    @Get('remove_profile')
    async remove_profile(@Req() request: Request) { 
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.remove_profile(getPayload);
    }

    @Post('send-login-otp')
    async send_login_otp(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.send_login_otp(getPayload);
    }
    @UseGuards(JwtAuthGuard)
    @Get('other_details')
    async other_details(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.AuthServices.other_details(getPayload);
    }


}
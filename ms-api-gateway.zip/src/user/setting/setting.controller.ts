import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";

import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { SettingsService } from "./setting.service";
import { JwtAuthGuard } from "../auth/gaurd/jwtguard";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL}setting`)
export class SettingsController {
    constructor(private readonly SettingService: SettingsService) { }
        
    @Get('get-website-setting')
    async payment_gateway(@Req() request: Request) {
        console.log("enter")
        const getPayload = await PayloadHelper(request);
        return await this.SettingService.get_website_setting(getPayload);
    }

    

}
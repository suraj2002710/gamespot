import { Injectable, Inject } from '@nestjs/common';
import { ClientProxy } from "@nestjs/microservices";
@Injectable()
export class SettingsService {
    constructor(@Inject("USER_MICROSERVICES") private authClientProxy: ClientProxy) { }

    async get_website_setting(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_website_setting' }, payload);
    }
}

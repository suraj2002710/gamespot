import { Controller, Get, Post, Req, UseGuards, UseInterceptors } from "@nestjs/common";
import { UserGamesService } from "./games.service";
import { JwtAuthGuard } from "../auth/gaurd/jwtguard";
import { PayloadHelper } from "src/utils/Payload";
import { CommonConfig } from "src/config/CommanConfig";
import { FileInterceptor } from "@nestjs/platform-express";

@UseGuards(JwtAuthGuard)
@Controller(`${CommonConfig.API_URL}games`)
export class UserGamesController{

    constructor(private readonly UserGamesService: UserGamesService){}

    
    @Post('get_user_game_history')
    async get_user_game_history(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.get_user_game_history(getPayload);
    }

    @Post('get_game')
    async get_game(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.get_game(getPayload);
    }

    @Post('create_game_challange')
    async create_game_challange(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.create_game_challange(getPayload);
    }

    @Post('delete_game_challange')
    async delete_game_challange(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.delete_game_challange(getPayload);
    }

    @Post('game_challange_accpect')
    async game_chalange_status(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_accpect(getPayload);
    }

    @Post('get_all_challanges')
    async get_all_running_challanges(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.get_all_running_challanges(getPayload);
    }

    @Post('game_challange_start')
    async game_challange_start(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_start(getPayload);
    }

    @Post('game_challange_requested')
    async game_challange_requested(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_requested(getPayload);
    }

    @Post('game_challange_running')
    async game_challange_running(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_running(getPayload);
    }

    @Post('game_challange_reject')
    async game_challange_reject(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_reject(getPayload);
    }
    @Post('get_single_challanges')
    async get_single_challanges(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.get_single_challanges(getPayload);
    }

    @Post('game_challange_result')
    async game_challange_result(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_result(getPayload);
    }

    @Post('update_room_code')
    async update_room_code(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.update_room_code(getPayload);
    }
    
    @Post('game_challange_update')
    async game_challange_update(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_update(getPayload);
    }

    @Post('game_challange_upload_result')
    @UseInterceptors(FileInterceptor("screenshot", {
        limits: {
            fileSize: 2 * 1024 * 1024, 
        },
        fileFilter: (req, file, cb) => {
            if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)) {
                
                cb(null, true);
            } else {
                cb(new Error('Invalid file type'), false);
            }
        },
    }))
    async game_challange_upload_result(@Req() request: Request) {
        const getPayload = await PayloadHelper(request);
        return await this.UserGamesService.game_challange_upload_result(getPayload);
    }
    
}

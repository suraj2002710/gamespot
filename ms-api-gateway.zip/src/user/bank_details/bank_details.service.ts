import { Inject, Injectable } from "@nestjs/common";
import { ClientProxy } from "@nestjs/microservices";



@Injectable()
export class User_BankDetail_Service {
    constructor(@Inject("USER_MICROSERVICES") private authClientProxy: ClientProxy
    ) { }
    async add_bank_details(payload: any) {
        return await this.authClientProxy.send({ cmd: 'add_bank_details' }, payload);
    }

    async bank_Otp_verify(payload: any) {
        return await this.authClientProxy.send({ cmd: 'bank_Otp_verify' }, payload);
    }

    async get_bank_and_upisDetails(payload: any) {
        return await this.authClientProxy.send({ cmd: 'get_bank_and_upisDetails' }, payload);
    }
}
import { Module } from "@nestjs/common";

import { ConfigModule } from "@nestjs/config";
import { ClientsModule, Transport } from "@nestjs/microservices";
import { CommonConfig } from "src/config/CommanConfig";
import { JwtModule } from "@nestjs/jwt";
import { Users, UsersSchema } from "src/schema/user.schema";
import { MongooseModule } from "@nestjs/mongoose";
import { PassportModule } from "@nestjs/passport";
import { FantasyController } from "./fantasy.controller";
import { FantasyService } from "./fantasy.service";

@Module({
    imports: [
        ConfigModule.forRoot(),
        ClientsModule.register([
            {
                name: 'FANTASY_MICROSERVICES',
                transport: Transport.TCP,
                options: {
                  host: <any>CommonConfig.HOST_FANTACY,
                  port: <any>CommonConfig.PORT_FANTACY
                }
              },
        ]),
        PassportModule,
        JwtModule.register({
            secret: CommonConfig.API_ACCESS_TOKEN_SECRET,
            signOptions: CommonConfig.API_ACCESS_TOKEN_SIGNOPTIONS,
        })
        ,
        MongooseModule.forFeature([{ name: Users.name, schema: UsersSchema }]),
    ],
    providers: [FantasyService],
    controllers: [FantasyController]
})
export class FantasyModule { }
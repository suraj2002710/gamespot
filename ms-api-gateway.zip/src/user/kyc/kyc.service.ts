import { Inject, Injectable } from "@nestjs/common"
import { JwtService } from "@nestjs/jwt";
import { ClientProxy } from "@nestjs/microservices";


@Injectable()
export class User_KycServices {
    constructor(@Inject("USER_MICROSERVICES") private authClientProxy: ClientProxy) { }

    async kyc_request(payload: any) {
        return await this.authClientProxy.send({ cmd: 'kyc_request' }, payload);
    }

    async auto_kyc_generate_otp(payload: any) {
        return await this.authClientProxy.send({ cmd: 'auto_kyc_generate_otp' }, payload);
    }

    async auto_kyc_otp_verify(payload: any) {
        return await this.authClientProxy.send({ cmd: 'auto_kyc_otp_verify' }, payload);
    }
    async update_Kyc_request(payload: any) {
        return await this.authClientProxy.send({ cmd: 'update_Kyc_request' }, payload);
    }
    async kyc_request_Otp_verify(payload: any) {
        return await this.authClientProxy.send({ cmd: 'kyc_request_Otp_verify' }, payload);
    }


}
